package com.thanpisitkub.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.thanpisitkub.ThanpisitkubMod;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/** Particle description converted from a Bedrock .particle.json (see assets/thanpisitkub/bedrock_particles). */
public final class BedrockSpec {
    public static final class Curve {
        final Molang.Expr input;
        final Molang.Expr range;
        final double[] nodes;

        Curve(Molang.Expr input, Molang.Expr range, double[] nodes) {
            this.input = input;
            this.range = range;
            this.nodes = nodes;
        }

        double eval(Molang.Ctx c) {
            int n = nodes.length;
            if (n == 0) return 0;
            if (n < 4) return nodes[n / 2];
            double rng = range.eval(c);
            double t = rng > 0 ? input.eval(c) / rng : 0;
            t = Math.max(0, Math.min(1, t));
            double u = t * (n - 3);
            int i = (int) Math.floor(u);
            if (i > n - 4) i = n - 4;
            double f = u - i;
            double p0 = nodes[i], p1 = nodes[i + 1], p2 = nodes[i + 2], p3 = nodes[i + 3];
            return 0.5 * ((2 * p1) + (-p0 + p2) * f + (2 * p0 - 5 * p1 + 4 * p2 - p3) * f * f + (-p0 + 3 * p1 - 3 * p2 + p3) * f * f * f);
        }
    }

    public final String name;
    public final boolean additive;
    public final String facing;   // camera | flat | vertical
    public final int frames;
    public final boolean hasFlip;
    public final double flipFps;
    public final int flipMax;
    public final boolean flipStretch;
    public final boolean flipLoop;
    public final boolean uvRandom;
    public final boolean steady;
    public final Molang.Expr count;
    public final Molang.Expr rate;
    public final double active;
    public final boolean sphere;
    public final Molang.Expr radius;
    public final Molang.Expr[] offset = new Molang.Expr[3];
    public final Molang.Expr speed;
    public final Molang.Expr[] accel = new Molang.Expr[3];
    public final double drag;
    public final Molang.Expr life;
    public final Molang.Expr sizeW;
    public final Molang.Expr sizeH;
    public final boolean tintConst;
    public final float[] tintRgba = new float[4];      // a r g b
    public final float[][] tintStops;                  // {t, a, r, g, b}
    public final Molang.Expr spinRot;
    public final Molang.Expr spinRate;
    public final Map<String, Curve> curves = new HashMap<>();

    private static Molang.Expr ex(JsonElement e) {
        return Molang.compile(e.getAsString());
    }

    private BedrockSpec(JsonObject o) {
        name = o.get("name").getAsString();
        additive = o.get("additive").getAsBoolean();
        facing = o.get("facing").getAsString();
        frames = o.get("frames").getAsInt();
        JsonElement fl = o.get("flipbook");
        if (fl != null && fl.isJsonObject()) {
            JsonObject f = fl.getAsJsonObject();
            hasFlip = true;
            flipFps = f.get("fps").getAsDouble();
            flipMax = f.get("max").getAsInt();
            flipStretch = f.get("stretch").getAsBoolean();
            flipLoop = f.get("loop").getAsBoolean();
        } else {
            hasFlip = false;
            flipFps = 0;
            flipMax = 1;
            flipStretch = false;
            flipLoop = false;
        }
        uvRandom = o.get("uv_random").getAsBoolean();
        JsonObject em = o.getAsJsonObject("emitter");
        steady = "steady".equals(em.get("mode").getAsString());
        count = ex(em.get("count"));
        rate = ex(em.get("rate"));
        active = em.get("active").getAsDouble();
        JsonObject sh = o.getAsJsonObject("shape");
        sphere = "sphere".equals(sh.get("type").getAsString());
        radius = ex(sh.get("radius"));
        JsonArray off = sh.getAsJsonArray("offset");
        for (int i = 0; i < 3; i++) offset[i] = ex(off.get(i));
        speed = ex(o.get("speed"));
        JsonArray ac = o.getAsJsonArray("accel");
        for (int i = 0; i < 3; i++) accel[i] = ex(ac.get(i));
        drag = o.get("drag").getAsDouble();
        life = ex(o.get("lifetime"));
        JsonArray sz = o.getAsJsonArray("size");
        sizeW = ex(sz.get(0));
        sizeH = ex(sz.get(1));
        JsonObject tn = o.getAsJsonObject("tint");
        if ("grad".equals(tn.get("mode").getAsString())) {
            tintConst = false;
            JsonArray st = tn.getAsJsonArray("stops");
            tintStops = new float[st.size()][5];
            for (int i = 0; i < st.size(); i++) {
                JsonArray s = st.get(i).getAsJsonArray();
                for (int k = 0; k < 5; k++) tintStops[i][k] = s.get(k).getAsFloat();
            }
        } else {
            tintConst = true;
            tintStops = new float[0][0];
            JsonArray r = tn.getAsJsonArray("rgba");
            for (int k = 0; k < 4; k++) tintRgba[k] = r.get(k).getAsFloat();
        }
        JsonObject sp = o.getAsJsonObject("spin");
        spinRot = ex(sp.get("rot"));
        spinRate = ex(sp.get("rate"));
        JsonObject cv = o.getAsJsonObject("curves");
        for (Map.Entry<String, JsonElement> e : cv.entrySet()) {
            JsonObject c = e.getValue().getAsJsonObject();
            JsonArray nd = c.getAsJsonArray("nodes");
            double[] nodes = new double[nd.size()];
            for (int i = 0; i < nodes.length; i++) nodes[i] = nd.get(i).getAsDouble();
            curves.put(e.getKey(), new Curve(ex(c.get("input")), ex(c.get("range")), nodes));
        }
    }

    public static BedrockSpec load(String name) {
        String path = "/assets/" + ThanpisitkubMod.MOD_ID + "/bedrock_particles/" + name + ".json";
        try (InputStream in = BedrockSpec.class.getResourceAsStream(path)) {
            if (in == null) return null;
            try (Reader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
                return new BedrockSpec(JsonParser.parseReader(r).getAsJsonObject());
            }
        } catch (Exception e) {
            ThanpisitkubMod.LOGGER.error("Could not load particle spec {}", name, e);
            return null;
        }
    }
}
