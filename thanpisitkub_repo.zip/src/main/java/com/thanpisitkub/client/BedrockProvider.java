package com.thanpisitkub.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.core.particles.SimpleParticleType;

public class BedrockProvider implements ParticleProvider<SimpleParticleType> {
    private final BedrockSpec spec;
    private final SpriteSet sprites;

    public BedrockProvider(String name, SpriteSet sprites) {
        this.spec = BedrockSpec.load(name);
        this.sprites = sprites;
    }

    @Override
    public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double dx, double dy, double dz) {
        if (spec == null) return null;
        return new BedrockEmitter(level, x, y, z, spec, sprites);
    }
}
