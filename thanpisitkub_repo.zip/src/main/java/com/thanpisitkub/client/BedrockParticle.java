package com.thanpisitkub.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/** One rendered particle (a Bedrock "billboard") with Bedrock-like motion, tint, flipbook and size. */
public class BedrockParticle extends TextureSheetParticle {
    private static final int FULL_BRIGHT = 15728880;

    private final BedrockSpec spec;
    private final SpriteSet sprites;
    private final Molang.Ctx ctx;
    private final float[] rnd = new float[4];
    private final float yawRad;
    private double vx, vy, vz, ax, ay, az;
    private float rollRate;
    private double ageSec, lifeSec;
    private float halfW = 0.5f, halfH = 0.5f;
    private int pickedFrame = 0;

    public BedrockParticle(ClientLevel level, double ex, double ey, double ez, BedrockSpec spec, SpriteSet sprites, float yawDeg) {
        super(level, ex, ey, ez);
        this.spec = spec;
        this.sprites = sprites;
        this.yawRad = (float) Math.toRadians(yawDeg);
        this.ctx = new Molang.Ctx() {
            @Override
            public double var(String name) {
                switch (name) {
                    case "particle_random_1": return rnd[0];
                    case "particle_random_2": return rnd[1];
                    case "particle_random_3": return rnd[2];
                    case "particle_random_4": return rnd[3];
                    case "particle_age": return ageSec;
                    case "particle_lifetime": return lifeSec;
                    default:
                        BedrockSpec.Curve c = BedrockParticle.this.spec.curves.get(name);
                        return c != null ? c.eval(this) : 0.0;
                }
            }

            @Override
            public double rnd() {
                return BedrockParticle.this.random.nextDouble();
            }
        };
        for (int i = 0; i < 4; i++) rnd[i] = this.random.nextFloat();
        this.hasPhysics = false;
        this.gravity = 0.0F;

        double life = Math.max(0.05, spec.life.eval(ctx));
        this.lifetime = Math.max(1, (int) Math.round(life * 20.0));
        this.lifeSec = this.lifetime * 0.05;

        // random unit direction
        double u = this.random.nextDouble() * 2.0 - 1.0;
        double th = this.random.nextDouble() * Math.PI * 2.0;
        double rr = Math.sqrt(1.0 - u * u);
        double dx = rr * Math.cos(th), dy = u, dz = rr * Math.sin(th);

        double lx, ly, lz;
        if (spec.sphere) {
            double rad = Math.max(0.0, spec.radius.eval(ctx));
            double k = rad * Math.cbrt(this.random.nextDouble());
            lx = dx * k;
            ly = dy * k;
            lz = dz * k;
        } else {
            lx = spec.offset[0].eval(ctx);
            ly = spec.offset[1].eval(ctx);
            lz = spec.offset[2].eval(ctx);
        }
        double sp = spec.speed.eval(ctx);
        double[] v = toWorld(dx * sp, dy * sp, dz * sp);
        this.vx = v[0];
        this.vy = v[1];
        this.vz = v[2];
        double[] a = toWorld(spec.accel[0].eval(ctx), spec.accel[1].eval(ctx), spec.accel[2].eval(ctx));
        this.ax = a[0];
        this.ay = a[1];
        this.az = a[2];
        double[] o = toWorld(lx, ly, lz);
        this.setPos(ex + o[0], ey + o[1], ez + o[2]);
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;

        this.roll = (float) Math.toRadians(spec.spinRot.eval(ctx));
        this.oRoll = this.roll;
        this.rollRate = (float) Math.toRadians(spec.spinRate.eval(ctx));
        if (spec.uvRandom) this.pickedFrame = this.random.nextInt(Math.max(1, spec.frames));
        updateVisual();
    }

    /** Bedrock local axes (x = right, y = up, -z = forward) to world axes for the emitter yaw. */
    private double[] toWorld(double lx, double ly, double lz) {
        double s = Math.sin(yawRad), c = Math.cos(yawRad);
        return new double[]{-lx * c + lz * s, ly, -lx * s - lz * c};
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        this.oRoll = this.roll;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        final double dt = 0.05;
        this.ageSec = this.age * dt;
        vx += (ax - spec.drag * vx) * dt;
        vy += (ay - spec.drag * vy) * dt;
        vz += (az - spec.drag * vz) * dt;
        this.setPos(this.x + vx * dt, this.y + vy * dt, this.z + vz * dt);
        this.roll += rollRate * (float) dt;
        updateVisual();
    }

    private void updateVisual() {
        float t = (float) Math.max(0.0, Math.min(1.0, lifeSec > 0 ? ageSec / lifeSec : 1.0));
        float a, r, g, b;
        if (spec.tintConst) {
            a = spec.tintRgba[0];
            r = spec.tintRgba[1];
            g = spec.tintRgba[2];
            b = spec.tintRgba[3];
        } else {
            float[][] s = spec.tintStops;
            float[] lo = s[0], hi = s[s.length - 1];
            float f = 0f;
            if (t <= s[0][0]) {
                hi = lo;
            } else if (t >= s[s.length - 1][0]) {
                lo = hi;
            } else {
                for (int i = 0; i < s.length - 1; i++) {
                    if (t <= s[i + 1][0]) {
                        lo = s[i];
                        hi = s[i + 1];
                        float span = hi[0] - lo[0];
                        f = span <= 0 ? 0f : (t - lo[0]) / span;
                        break;
                    }
                }
            }
            a = lo[1] + (hi[1] - lo[1]) * f;
            r = lo[2] + (hi[2] - lo[2]) * f;
            g = lo[3] + (hi[3] - lo[3]) * f;
            b = lo[4] + (hi[4] - lo[4]) * f;
        }
        this.alpha = a;
        this.rCol = r;
        this.gCol = g;
        this.bCol = b;

        this.halfW = (float) Math.max(0.0, spec.sizeW.eval(ctx) * 0.5);
        this.halfH = (float) Math.max(0.0, spec.sizeH.eval(ctx) * 0.5);

        int n = Math.max(1, spec.frames);
        int idx = 0;
        if (n > 1) {
            if (spec.uvRandom) {
                idx = pickedFrame;
            } else if (spec.hasFlip) {
                int mf = Math.min(n, Math.max(1, spec.flipMax));
                if (spec.flipStretch) {
                    idx = (int) Math.min(mf - 1, Math.floor((lifeSec > 0 ? ageSec / lifeSec : 1.0) * mf));
                } else {
                    int fr = (int) Math.floor(spec.flipFps * ageSec);
                    idx = spec.flipLoop ? (fr % mf) : Math.min(mf - 1, fr);
                }
            }
            this.setSprite(sprites.get(idx, n - 1));
        } else {
            this.setSprite(sprites.get(0, 1));
        }
    }

    @Override
    public void render(VertexConsumer vc, Camera camera, float partialTicks) {
        if (this.sprite == null) return;
        Vec3 cam = camera.getPosition();
        float px = (float) (Mth.lerp(partialTicks, this.xo, this.x) - cam.x());
        float py = (float) (Mth.lerp(partialTicks, this.yo, this.y) - cam.y());
        float pz = (float) (Mth.lerp(partialTicks, this.zo, this.z) - cam.z());
        float rollNow = Mth.lerp(partialTicks, this.oRoll, this.roll);

        Quaternionf q;
        if ("flat".equals(spec.facing)) {
            q = new Quaternionf().rotationX(-Mth.HALF_PI);
            q.rotateZ(rollNow);
        } else if ("vertical".equals(spec.facing)) {
            q = new Quaternionf().rotationY(-(yawRad + Mth.HALF_PI));
        } else {
            q = new Quaternionf(camera.rotation());
            q.rotateZ(rollNow);
        }

        Vector3f[] verts = new Vector3f[]{
                new Vector3f(-1.0F, -1.0F, 0.0F),
                new Vector3f(-1.0F, 1.0F, 0.0F),
                new Vector3f(1.0F, 1.0F, 0.0F),
                new Vector3f(1.0F, -1.0F, 0.0F)};
        for (Vector3f v : verts) {
            v.mul(halfW, halfH, 1.0F);
            v.rotate(q);
            v.add(px, py, pz);
        }
        float u0 = this.sprite.getU0(), u1 = this.sprite.getU1();
        float v0 = this.sprite.getV0(), v1 = this.sprite.getV1();
        vc.vertex(verts[0].x(), verts[0].y(), verts[0].z()).uv(u1, v1).color(this.rCol, this.gCol, this.bCol, this.alpha).uv2(FULL_BRIGHT).endVertex();
        vc.vertex(verts[1].x(), verts[1].y(), verts[1].z()).uv(u1, v0).color(this.rCol, this.gCol, this.bCol, this.alpha).uv2(FULL_BRIGHT).endVertex();
        vc.vertex(verts[2].x(), verts[2].y(), verts[2].z()).uv(u0, v0).color(this.rCol, this.gCol, this.bCol, this.alpha).uv2(FULL_BRIGHT).endVertex();
        vc.vertex(verts[3].x(), verts[3].y(), verts[3].z()).uv(u0, v1).color(this.rCol, this.gCol, this.bCol, this.alpha).uv2(FULL_BRIGHT).endVertex();
    }

    @Override
    public ParticleRenderType getRenderType() {
        return spec.additive ? RenderTypes.ADD : RenderTypes.BLEND;
    }

    /** Huge effects must not be frustum-culled by their tiny bounding box. */
    public boolean shouldCull() {
        return false;
    }
}
