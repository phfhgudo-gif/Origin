package com.thanpisitkub.client;

import com.thanpisitkub.ThanpisitkubMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.Entity;

public final class ClientAnim {
    private ClientAnim() {}

    /** action: 0 = stop, 1 = galaxy_impact, 2 = galaxy_divide */
    public static void play(int entityId, int action) {
        if (!PlayerAnimSupport.present()) return;
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        Entity e = level.getEntity(entityId);
        if (!(e instanceof AbstractClientPlayer)) return;
        try {
            String name = action == 1 ? "galaxy_impact" : (action == 2 ? "galaxy_divide" : null);
            PlayerAnimBridge.play((AbstractClientPlayer) e, name);
        } catch (Throwable t) {
            ThanpisitkubMod.LOGGER.error("Could not play player animation", t);
        }
    }
}
