package com.thanpisitkub.client;

import java.util.HashMap;
import java.util.Map;

/** Tiny Molang subset: numbers, + - * /, parentheses, math.* functions and v.* variables. */
public final class Molang {
    public interface Ctx {
        double var(String name);
        double rnd();
    }

    public interface Expr {
        double eval(Ctx c);
    }

    private static final Map<String, Expr> CACHE = new HashMap<>();

    private Molang() {}

    public static synchronized Expr compile(String src) {
        Expr e = CACHE.get(src);
        if (e == null) {
            try {
                e = new Parser(src).parse();
            } catch (RuntimeException ex) {
                e = c -> 0.0;
            }
            CACHE.put(src, e);
        }
        return e;
    }

    private static final class Parser {
        private final String s;
        private int p = 0;

        Parser(String src) {
            this.s = src.toLowerCase().replace(" ", "").replace("\t", "").replace("\n", "");
        }

        Expr parse() {
            return expr();
        }

        private boolean more() {
            return p < s.length();
        }

        private char peek() {
            return s.charAt(p);
        }

        private Expr expr() {
            Expr left = term();
            while (more() && (peek() == '+' || peek() == '-')) {
                char op = s.charAt(p++);
                final Expr a = left;
                final Expr b = term();
                left = (op == '+') ? (c -> a.eval(c) + b.eval(c)) : (c -> a.eval(c) - b.eval(c));
            }
            return left;
        }

        private Expr term() {
            Expr left = unary();
            while (more() && (peek() == '*' || peek() == '/')) {
                char op = s.charAt(p++);
                final Expr a = left;
                final Expr b = unary();
                if (op == '*') {
                    left = c -> a.eval(c) * b.eval(c);
                } else {
                    left = c -> {
                        double d = b.eval(c);
                        return d == 0.0 ? 0.0 : a.eval(c) / d;
                    };
                }
            }
            return left;
        }

        private Expr unary() {
            if (more() && peek() == '-') {
                p++;
                final Expr a = unary();
                return c -> -a.eval(c);
            }
            if (more() && peek() == '+') {
                p++;
                return unary();
            }
            return primary();
        }

        private Expr primary() {
            if (!more()) throw new IllegalStateException("eof");
            char ch = peek();
            if (ch == '(') {
                p++;
                Expr e = expr();
                if (more() && peek() == ')') p++;
                return e;
            }
            if (Character.isDigit(ch) || ch == '.') {
                int st = p;
                while (more() && (Character.isDigit(peek()) || peek() == '.')) p++;
                final double v = Double.parseDouble(s.substring(st, p));
                return c -> v;
            }
            int st = p;
            while (more() && (Character.isLetterOrDigit(peek()) || peek() == '_' || peek() == '.')) p++;
            if (st == p) throw new IllegalStateException("bad char " + ch);
            String id = s.substring(st, p);
            if (more() && peek() == '(') {
                p++;
                java.util.List<Expr> args = new java.util.ArrayList<>();
                if (more() && peek() != ')') {
                    args.add(expr());
                    while (more() && peek() == ',') {
                        p++;
                        args.add(expr());
                    }
                }
                if (more() && peek() == ')') p++;
                return func(id, args);
            }
            String name = id;
            if (name.startsWith("variable.")) name = name.substring(9);
            else if (name.startsWith("v.")) name = name.substring(2);
            final String key = name;
            return c -> c.var(key);
        }

        private Expr func(String id, java.util.List<Expr> a) {
            switch (id) {
                case "math.random": {
                    final Expr lo = a.size() > 0 ? a.get(0) : (c -> 0.0);
                    final Expr hi = a.size() > 1 ? a.get(1) : (c -> 1.0);
                    return c -> {
                        double l = lo.eval(c);
                        double h = hi.eval(c);
                        return l + (h - l) * c.rnd();
                    };
                }
                case "math.round": {
                    final Expr x = a.get(0);
                    return c -> (double) Math.round(x.eval(c));
                }
                case "math.floor": {
                    final Expr x = a.get(0);
                    return c -> Math.floor(x.eval(c));
                }
                case "math.ceil": {
                    final Expr x = a.get(0);
                    return c -> Math.ceil(x.eval(c));
                }
                case "math.abs": {
                    final Expr x = a.get(0);
                    return c -> Math.abs(x.eval(c));
                }
                case "math.sin": {
                    final Expr x = a.get(0);
                    return c -> Math.sin(Math.toRadians(x.eval(c)));
                }
                case "math.cos": {
                    final Expr x = a.get(0);
                    return c -> Math.cos(Math.toRadians(x.eval(c)));
                }
                case "math.min": {
                    final Expr x = a.get(0);
                    final Expr y = a.get(1);
                    return c -> Math.min(x.eval(c), y.eval(c));
                }
                case "math.max": {
                    final Expr x = a.get(0);
                    final Expr y = a.get(1);
                    return c -> Math.max(x.eval(c), y.eval(c));
                }
                case "math.sqrt": {
                    final Expr x = a.get(0);
                    return c -> Math.sqrt(Math.max(0.0, x.eval(c)));
                }
                default:
                    return c -> 0.0;
            }
        }
    }
}
