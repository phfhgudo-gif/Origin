package com.thanpisitkub.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.world.entity.player.Player;

/** Invisible particle that behaves like a Bedrock emitter: spawns the visible BedrockParticles. */
public class BedrockEmitter extends Particle {
    private final BedrockSpec spec;
    private final SpriteSet sprites;
    private final float yawDeg;
    private final Molang.Ctx ctx;
    private double carry = 0.0;

    public BedrockEmitter(ClientLevel level, double x, double y, double z, BedrockSpec spec, SpriteSet sprites) {
        super(level, x, y, z);
        this.spec = spec;
        this.sprites = sprites;
        Player p = level.getNearestPlayer(x, y, z, 10.0, false);
        this.yawDeg = p != null ? p.getYRot() : 0.0F;
        this.lifetime = spec.steady ? Math.max(1, (int) Math.round(spec.active * 20.0)) : 1;
        this.ctx = new Molang.Ctx() {
            @Override
            public double var(String name) {
                return 0.0;
            }

            @Override
            public double rnd() {
                return BedrockEmitter.this.random.nextDouble();
            }
        };
    }

    @Override
    public void tick() {
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        int n;
        if (spec.steady) {
            carry += Math.max(0.0, spec.rate.eval(ctx)) / 20.0;
            n = (int) Math.floor(carry);
            carry -= n;
        } else {
            n = (this.age == 1) ? (int) Math.round(Math.max(0.0, spec.count.eval(ctx))) : 0;
        }
        n = Math.min(n, 300);
        Minecraft mc = Minecraft.getInstance();
        for (int i = 0; i < n; i++) {
            mc.particleEngine.add(new BedrockParticle(this.level, this.x, this.y, this.z, spec, sprites, yawDeg));
        }
        if (!spec.steady) this.remove();
    }

    @Override
    public void render(VertexConsumer vc, Camera camera, float partialTicks) {
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.NO_RENDER;
    }
}
