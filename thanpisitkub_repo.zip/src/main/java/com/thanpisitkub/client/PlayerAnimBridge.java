package com.thanpisitkub.client;

import com.thanpisitkub.ThanpisitkubMod;
import dev.kosmx.playerAnim.api.layered.IAnimation;
import dev.kosmx.playerAnim.api.layered.KeyframeAnimationPlayer;
import dev.kosmx.playerAnim.api.layered.ModifierLayer;
import dev.kosmx.playerAnim.core.data.KeyframeAnimation;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationAccess;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationFactory;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationRegistry;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.resources.ResourceLocation;

/** The only class that touches the Player Animator API. Only call it when PlayerAnimSupport.present(). */
public final class PlayerAnimBridge {
    private static final ResourceLocation LAYER = new ResourceLocation(ThanpisitkubMod.MOD_ID, "animation");

    private PlayerAnimBridge() {}

    public static void init() {
        PlayerAnimationFactory.ANIMATION_DATA_FACTORY.registerFactory(LAYER, 42, PlayerAnimBridge::createLayer);
    }

    private static IAnimation createLayer(AbstractClientPlayer player) {
        return new ModifierLayer<>();
    }

    @SuppressWarnings("unchecked")
    public static void play(AbstractClientPlayer player, String name) {
        ModifierLayer<IAnimation> layer = (ModifierLayer<IAnimation>) PlayerAnimationAccess.getPlayerAssociatedData(player).get(LAYER);
        if (layer == null) return;
        if (name == null) {
            layer.setAnimation(null);
            return;
        }
        KeyframeAnimation anim = PlayerAnimationRegistry.getAnimation(new ResourceLocation(ThanpisitkubMod.MOD_ID, name));
        if (anim == null) {
            ThanpisitkubMod.LOGGER.warn("Player animation {} was not found", name);
            return;
        }
        layer.setAnimation(new KeyframeAnimationPlayer(anim));
    }
}
