package com.thanpisitkub.client;

/** Checks (without touching any Player Animator class) whether the Player Animator mod is installed. */
public final class PlayerAnimSupport {
    private static Boolean present;

    private PlayerAnimSupport() {}

    public static boolean present() {
        if (present == null) {
            try {
                Class.forName("dev.kosmx.playerAnim.api.layered.ModifierLayer", false, PlayerAnimSupport.class.getClassLoader());
                present = Boolean.TRUE;
            } catch (Throwable t) {
                present = Boolean.FALSE;
            }
        }
        return present;
    }
}
