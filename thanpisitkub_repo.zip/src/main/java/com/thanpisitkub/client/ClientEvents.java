package com.thanpisitkub.client;

import com.thanpisitkub.ModParticles;
import com.thanpisitkub.ThanpisitkubMod;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.registries.RegistryObject;

import java.util.Map;

@Mod.EventBusSubscriber(modid = ThanpisitkubMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() {}

    @SubscribeEvent
    public static void registerParticles(RegisterParticleProvidersEvent event) {
        for (Map.Entry<String, RegistryObject<SimpleParticleType>> entry : ModParticles.TYPES.entrySet()) {
            final String name = entry.getKey();
            event.registerSpriteSet(entry.getValue().get(), sprites -> new BedrockProvider(name, sprites));
        }
    }

    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            if (PlayerAnimSupport.present()) {
                try {
                    PlayerAnimBridge.init();
                } catch (Throwable t) {
                    ThanpisitkubMod.LOGGER.error("Could not register the player animation layer", t);
                }
            } else {
                ThanpisitkubMod.LOGGER.warn("Player Animator is not installed: moves will run without body animation.");
            }
        });
    }
}
