package com.thanpisitkub;

import com.mojang.logging.LogUtils;
import com.thanpisitkub.net.Net;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(ThanpisitkubMod.MOD_ID)
public class ThanpisitkubMod {
    public static final String MOD_ID = "thanpisitkub";
    public static final Logger LOGGER = LogUtils.getLogger();

    public ThanpisitkubMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModParticles.REGISTER.register(bus);
        bus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(Net::register);
    }
}
