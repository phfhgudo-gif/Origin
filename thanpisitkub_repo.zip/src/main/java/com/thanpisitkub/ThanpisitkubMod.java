package com.thanpisitkub;

import net.minecraftforge.fml.common.Mod;

/**
 * Empty mod class. All the content (origin, powers, functions, sounds)
 * is data-driven and lives in src/main/resources (data/ and assets/).
 */
@Mod(ThanpisitkubMod.MOD_ID)
public class ThanpisitkubMod {
    public static final String MOD_ID = "thanpisitkub";

    public ThanpisitkubMod() {
    }
}
