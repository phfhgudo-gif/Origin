package com.thanpisitkub;

import com.thanpisitkub.net.Net;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** /thanpisitkub anim <galaxy_impact|galaxy_divide|stop> : plays the body animation on the command's player. */
@Mod.EventBusSubscriber(modid = ThanpisitkubMod.MOD_ID)
public final class ModCommands {
    private ModCommands() {}

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("thanpisitkub")
                .then(Commands.literal("anim")
                        .then(Commands.literal("galaxy_impact").executes(c -> play(c.getSource(), 1)))
                        .then(Commands.literal("galaxy_divide").executes(c -> play(c.getSource(), 2)))
                        .then(Commands.literal("stop").executes(c -> play(c.getSource(), 0)))));
    }

    private static int play(CommandSourceStack source, int action) {
        ServerPlayer player = source.getPlayer();
        if (player == null) return 0;
        Net.sendAnim(player, action);
        return 1;
    }
}
