package com.thanpisitkub;

import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.LinkedHashMap;
import java.util.Map;

/** One particle type per converted Bedrock effect, e.g. /particle thanpisitkub:garp_ult1_2 ~ ~ ~ */
public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> REGISTER =
            DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, ThanpisitkubMod.MOD_ID);

    public static final String[] NAMES = {
            "garp_galaxydivide1",
            "garp_galaxydivide2",
            "garp_rubi2",
            "garp_rubi2_4",
            "garp_skills4_1",
            "garp_ult1_1",
            "garp_ult1_1_2",
            "garp_ult1_2",
            "garp_ult1_2_2",
            "garp_ult1_3_3",
            "garp_ult1_4_2",
            "garp_ult1_6",
            "garp_ult1_6_2",
            "garp_ult1_8_2",
            "garp_ult4_2",
            "garp_ult4_2_3",
            "garp_ult4_5",
            "garp_ult4_5_2"
    };

    public static final Map<String, RegistryObject<SimpleParticleType>> TYPES = new LinkedHashMap<>();

    static {
        for (String name : NAMES) {
            TYPES.put(name, REGISTER.register(name, () -> new SimpleParticleType(true)));
        }
    }

    private ModParticles() {}
}
