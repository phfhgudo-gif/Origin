package com.thanpisitkub.net;

import com.thanpisitkub.client.ClientAnim;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class AnimPacket {
    private final int entityId;
    private final int action;

    public AnimPacket(int entityId, int action) {
        this.entityId = entityId;
        this.action = action;
    }

    public static void encode(AnimPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.entityId);
        buf.writeVarInt(msg.action);
    }

    public static AnimPacket decode(FriendlyByteBuf buf) {
        return new AnimPacket(buf.readVarInt(), buf.readVarInt());
    }

    public static void handle(AnimPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientAnim.play(msg.entityId, msg.action)));
        ctx.get().setPacketHandled(true);
    }
}
