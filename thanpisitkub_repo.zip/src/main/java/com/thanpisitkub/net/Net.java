package com.thanpisitkub.net;

import com.thanpisitkub.ThanpisitkubMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class Net {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ThanpisitkubMod.MOD_ID, "main"), () -> PROTOCOL, s -> true, s -> true);

    private Net() {}

    public static void register() {
        CHANNEL.registerMessage(0, AnimPacket.class, AnimPacket::encode, AnimPacket::decode, AnimPacket::handle);
    }

    public static void sendAnim(ServerPlayer player, int action) {
        CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> player), new AnimPacket(player.getId(), action));
    }
}
