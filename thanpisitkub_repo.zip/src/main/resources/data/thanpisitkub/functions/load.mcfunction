scoreboard objectives add thp_gi dummy
scoreboard objectives add thp_gd dummy
scoreboard objectives add thp_death deathCount
