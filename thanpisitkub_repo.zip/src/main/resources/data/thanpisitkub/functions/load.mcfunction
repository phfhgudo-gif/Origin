scoreboard objectives add thp_gi dummy
scoreboard objectives add thp_gd dummy
scoreboard objectives add thp_tmp dummy
scoreboard objectives add thp_const dummy
scoreboard objectives add thp_death deathCount
scoreboard players set #5 thp_const 5
scoreboard players set #3 thp_const 3
