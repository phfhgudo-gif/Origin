execute rotated ~ 0 run particle thanpisitkub:garp_ult1_6_2 ^0.0 ^9.66 ^1.0 0 0 0 0 1 force
