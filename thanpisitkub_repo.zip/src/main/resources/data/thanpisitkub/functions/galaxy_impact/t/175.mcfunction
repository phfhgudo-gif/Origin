execute rotated ~ 0 run particle thanpisitkub:garp_ult1_6 ^0.0 ^7.19 ^1.0 0 0 0 0 1 force
