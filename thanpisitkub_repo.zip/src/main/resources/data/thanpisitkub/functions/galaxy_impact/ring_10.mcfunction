particle minecraft:dust 1 0.15 0 3 ~17.0 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~17.0 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~16.85 ~0.3 ~2.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~16.85 ~0.2 ~2.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~16.42 ~0.3 ~4.4 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~16.42 ~0.2 ~4.4 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~15.71 ~0.3 ~6.51 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~15.71 ~0.2 ~6.51 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~14.72 ~0.3 ~8.5 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~14.72 ~0.2 ~8.5 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.49 ~0.3 ~10.35 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.49 ~0.2 ~10.35 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~12.02 ~0.3 ~12.02 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~12.02 ~0.2 ~12.02 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~10.35 ~0.3 ~13.49 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~10.35 ~0.2 ~13.49 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~8.5 ~0.3 ~14.72 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~8.5 ~0.2 ~14.72 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~6.51 ~0.3 ~15.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~6.51 ~0.2 ~15.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~4.4 ~0.3 ~16.42 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~4.4 ~0.2 ~16.42 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~2.22 ~0.3 ~16.85 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~2.22 ~0.2 ~16.85 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~0.0 ~0.3 ~17.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~0.0 ~0.2 ~17.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.22 ~0.3 ~16.85 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.22 ~0.2 ~16.85 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.4 ~0.3 ~16.42 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.4 ~0.2 ~16.42 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.51 ~0.3 ~15.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.51 ~0.2 ~15.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.5 ~0.3 ~14.72 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.5 ~0.2 ~14.72 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.35 ~0.3 ~13.49 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.35 ~0.2 ~13.49 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-12.02 ~0.3 ~12.02 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-12.02 ~0.2 ~12.02 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.49 ~0.3 ~10.35 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.49 ~0.2 ~10.35 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-14.72 ~0.3 ~8.5 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-14.72 ~0.2 ~8.5 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.71 ~0.3 ~6.51 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.71 ~0.2 ~6.51 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-16.42 ~0.3 ~4.4 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-16.42 ~0.2 ~4.4 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-16.85 ~0.3 ~2.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-16.85 ~0.2 ~2.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.0 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.0 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-16.85 ~0.3 ~-2.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-16.85 ~0.2 ~-2.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-16.42 ~0.3 ~-4.4 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-16.42 ~0.2 ~-4.4 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.71 ~0.3 ~-6.51 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.71 ~0.2 ~-6.51 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-14.72 ~0.3 ~-8.5 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-14.72 ~0.2 ~-8.5 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.49 ~0.3 ~-10.35 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.49 ~0.2 ~-10.35 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-12.02 ~0.3 ~-12.02 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-12.02 ~0.2 ~-12.02 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.35 ~0.3 ~-13.49 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.35 ~0.2 ~-13.49 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.5 ~0.3 ~-14.72 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.5 ~0.2 ~-14.72 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.51 ~0.3 ~-15.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.51 ~0.2 ~-15.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.4 ~0.3 ~-16.42 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.4 ~0.2 ~-16.42 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.22 ~0.3 ~-16.85 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.22 ~0.2 ~-16.85 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-0.0 ~0.3 ~-17.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-0.0 ~0.2 ~-17.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~2.22 ~0.3 ~-16.85 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~2.22 ~0.2 ~-16.85 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~4.4 ~0.3 ~-16.42 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~4.4 ~0.2 ~-16.42 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~6.51 ~0.3 ~-15.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~6.51 ~0.2 ~-15.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~8.5 ~0.3 ~-14.72 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~8.5 ~0.2 ~-14.72 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~10.35 ~0.3 ~-13.49 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~10.35 ~0.2 ~-13.49 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~12.02 ~0.3 ~-12.02 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~12.02 ~0.2 ~-12.02 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.49 ~0.3 ~-10.35 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.49 ~0.2 ~-10.35 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~14.72 ~0.3 ~-8.5 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~14.72 ~0.2 ~-8.5 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~15.71 ~0.3 ~-6.51 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~15.71 ~0.2 ~-6.51 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~16.42 ~0.3 ~-4.4 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~16.42 ~0.2 ~-4.4 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~16.85 ~0.3 ~-2.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~16.85 ~0.2 ~-2.22 0.3 0.2 0.3 0.05 1 force
