execute rotated ~ 0 run particle thanpisitkub:garp_rubi2_4 ^0 ^1.0 ^0 0 0 0 0 1 force
particle minecraft:explosion_emitter ~ ~1 ~ 3 0.2 3 0 6 force
particle minecraft:flash ~ ~1 ~ 0 0 0 0 1 force
particle minecraft:sonic_boom ~ ~1 ~ 0 0 0 0 1 force
playsound minecraft:entity.generic.explode master @a ~ ~ ~ 8 0.5
playsound minecraft:entity.lightning_bolt.thunder master @a ~ ~ ~ 8 0.5
damage @e[tag=!thp_caster,distance=..25] 30 minecraft:player_attack by @s
