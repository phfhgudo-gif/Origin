execute rotated ~ 0 run particle thanpisitkub:garp_rubi2 ^0 ^1.0 ^0 0 0 0 0 1 force
