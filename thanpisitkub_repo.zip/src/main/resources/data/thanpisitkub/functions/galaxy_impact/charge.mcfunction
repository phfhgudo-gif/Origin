particle minecraft:dust 1 0.15 0 2.5 ~ ~1 ~ 0.9 1.1 0.9 0 6 force
particle minecraft:dust_color_transition 1 0.55 0 2 0.5 0 0 ~ ~0.1 ~ 1.6 0.1 1.6 0 8 force
particle minecraft:flame ~ ~0.2 ~ 0.6 0.1 0.6 0.08 4 force
particle minecraft:electric_spark ~ ~1 ~ 1.2 1.2 1.2 0.3 3 force
particle minecraft:dust 0.25 0 0 3 ~ ~1 ~ 1.4 1.4 1.4 0 4 force
execute if score @s thp_gi matches 20 run playsound minecraft:entity.generic.explode master @a ~ ~ ~ 2 0.6
execute if score @s thp_gi matches 50 run playsound minecraft:entity.generic.explode master @a ~ ~ ~ 2 0.5
