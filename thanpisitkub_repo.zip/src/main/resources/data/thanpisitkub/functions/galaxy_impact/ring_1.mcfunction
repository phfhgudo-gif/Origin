particle minecraft:dust 1 0.15 0 3 ~3.5 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.5 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~2.83 ~0.3 ~2.06 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~2.83 ~0.2 ~2.06 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.08 ~0.3 ~3.33 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.08 ~0.2 ~3.33 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.08 ~0.3 ~3.33 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.08 ~0.2 ~3.33 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.83 ~0.3 ~2.06 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.83 ~0.2 ~2.06 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.5 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.5 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.83 ~0.3 ~-2.06 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.83 ~0.2 ~-2.06 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.08 ~0.3 ~-3.33 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.08 ~0.2 ~-3.33 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.08 ~0.3 ~-3.33 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.08 ~0.2 ~-3.33 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~2.83 ~0.3 ~-2.06 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~2.83 ~0.2 ~-2.06 0.3 0.2 0.3 0.05 1 force
