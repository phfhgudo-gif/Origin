execute rotated ~ 0 run particle thanpisitkub:garp_rubi2 ^0 ^1.0 ^0 0 0 0 0 1 force
execute rotated ~ 0 run particle thanpisitkub:garp_ult1_4_2 ^-0.5 ^1.3 ^0.8 0 0 0 0 1 force
playsound minecraft:entity.generic.explode master @a ~ ~ ~ 5 0.7
particle minecraft:flash ^ ^1 ^3 0 0 0 0 1 force
damage @e[tag=!thp_caster,distance=..12] 12 minecraft:player_attack by @s
