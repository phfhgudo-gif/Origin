effect clear @s minecraft:slow_falling
tag @s remove thp_caster
scoreboard players reset @s thp_gi
