particle minecraft:dust 1 0.15 0 3 ~26.0 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~26.0 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~25.91 ~0.3 ~2.2 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~25.91 ~0.2 ~2.2 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~25.63 ~0.3 ~4.39 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~25.63 ~0.2 ~4.39 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~25.16 ~0.3 ~6.55 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~25.16 ~0.2 ~6.55 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~24.51 ~0.3 ~8.66 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~24.51 ~0.2 ~8.66 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~23.69 ~0.3 ~10.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~23.69 ~0.2 ~10.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~22.7 ~0.3 ~12.68 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~22.7 ~0.2 ~12.68 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~21.54 ~0.3 ~14.56 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~21.54 ~0.2 ~14.56 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~20.23 ~0.3 ~16.33 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~20.23 ~0.2 ~16.33 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~18.77 ~0.3 ~17.99 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~18.77 ~0.2 ~17.99 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~17.18 ~0.3 ~19.52 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~17.18 ~0.2 ~19.52 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~15.46 ~0.3 ~20.9 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~15.46 ~0.2 ~20.9 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.63 ~0.3 ~22.14 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.63 ~0.2 ~22.14 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~11.71 ~0.3 ~23.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.71 ~0.2 ~23.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.69 ~0.3 ~24.13 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.69 ~0.2 ~24.13 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.61 ~0.3 ~24.86 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.61 ~0.2 ~24.86 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~5.48 ~0.3 ~25.42 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~5.48 ~0.2 ~25.42 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.3 ~0.3 ~25.79 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.3 ~0.2 ~25.79 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.1 ~0.3 ~25.98 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.1 ~0.2 ~25.98 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.1 ~0.3 ~25.98 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.1 ~0.2 ~25.98 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.3 ~0.3 ~25.79 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.3 ~0.2 ~25.79 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-5.48 ~0.3 ~25.42 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-5.48 ~0.2 ~25.42 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-7.61 ~0.3 ~24.86 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-7.61 ~0.2 ~24.86 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-9.69 ~0.3 ~24.13 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-9.69 ~0.2 ~24.13 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-11.71 ~0.3 ~23.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-11.71 ~0.2 ~23.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.63 ~0.3 ~22.14 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.63 ~0.2 ~22.14 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.46 ~0.3 ~20.9 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.46 ~0.2 ~20.9 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.18 ~0.3 ~19.52 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.18 ~0.2 ~19.52 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-18.77 ~0.3 ~17.99 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-18.77 ~0.2 ~17.99 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-20.23 ~0.3 ~16.33 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-20.23 ~0.2 ~16.33 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-21.54 ~0.3 ~14.56 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-21.54 ~0.2 ~14.56 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-22.7 ~0.3 ~12.68 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-22.7 ~0.2 ~12.68 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-23.69 ~0.3 ~10.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-23.69 ~0.2 ~10.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-24.51 ~0.3 ~8.66 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-24.51 ~0.2 ~8.66 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-25.16 ~0.3 ~6.55 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-25.16 ~0.2 ~6.55 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-25.63 ~0.3 ~4.39 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-25.63 ~0.2 ~4.39 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-25.91 ~0.3 ~2.2 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-25.91 ~0.2 ~2.2 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-26.0 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-26.0 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-25.91 ~0.3 ~-2.2 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-25.91 ~0.2 ~-2.2 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-25.63 ~0.3 ~-4.39 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-25.63 ~0.2 ~-4.39 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-25.16 ~0.3 ~-6.55 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-25.16 ~0.2 ~-6.55 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-24.51 ~0.3 ~-8.66 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-24.51 ~0.2 ~-8.66 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-23.69 ~0.3 ~-10.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-23.69 ~0.2 ~-10.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-22.7 ~0.3 ~-12.68 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-22.7 ~0.2 ~-12.68 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-21.54 ~0.3 ~-14.56 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-21.54 ~0.2 ~-14.56 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-20.23 ~0.3 ~-16.33 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-20.23 ~0.2 ~-16.33 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-18.77 ~0.3 ~-17.99 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-18.77 ~0.2 ~-17.99 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.18 ~0.3 ~-19.52 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.18 ~0.2 ~-19.52 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.46 ~0.3 ~-20.9 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.46 ~0.2 ~-20.9 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.63 ~0.3 ~-22.14 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.63 ~0.2 ~-22.14 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-11.71 ~0.3 ~-23.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-11.71 ~0.2 ~-23.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-9.69 ~0.3 ~-24.13 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-9.69 ~0.2 ~-24.13 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-7.61 ~0.3 ~-24.86 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-7.61 ~0.2 ~-24.86 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-5.48 ~0.3 ~-25.42 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-5.48 ~0.2 ~-25.42 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.3 ~0.3 ~-25.79 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.3 ~0.2 ~-25.79 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.1 ~0.3 ~-25.98 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.1 ~0.2 ~-25.98 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.1 ~0.3 ~-25.98 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.1 ~0.2 ~-25.98 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.3 ~0.3 ~-25.79 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.3 ~0.2 ~-25.79 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~5.48 ~0.3 ~-25.42 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~5.48 ~0.2 ~-25.42 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.61 ~0.3 ~-24.86 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.61 ~0.2 ~-24.86 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.69 ~0.3 ~-24.13 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.69 ~0.2 ~-24.13 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~11.71 ~0.3 ~-23.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.71 ~0.2 ~-23.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.63 ~0.3 ~-22.14 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.63 ~0.2 ~-22.14 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~15.46 ~0.3 ~-20.9 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~15.46 ~0.2 ~-20.9 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~17.18 ~0.3 ~-19.52 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~17.18 ~0.2 ~-19.52 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~18.77 ~0.3 ~-17.99 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~18.77 ~0.2 ~-17.99 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~20.23 ~0.3 ~-16.33 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~20.23 ~0.2 ~-16.33 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~21.54 ~0.3 ~-14.56 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~21.54 ~0.2 ~-14.56 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~22.7 ~0.3 ~-12.68 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~22.7 ~0.2 ~-12.68 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~23.69 ~0.3 ~-10.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~23.69 ~0.2 ~-10.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~24.51 ~0.3 ~-8.66 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~24.51 ~0.2 ~-8.66 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~25.16 ~0.3 ~-6.55 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~25.16 ~0.2 ~-6.55 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~25.63 ~0.3 ~-4.39 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~25.63 ~0.2 ~-4.39 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~25.91 ~0.3 ~-2.2 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~25.91 ~0.2 ~-2.2 0.3 0.2 0.3 0.05 1 force
