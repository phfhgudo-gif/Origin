execute rotated ~ 0 run particle thanpisitkub:garp_ult1_2 ^-0.5 ^1.3 ^0.8 0 0 0 0 1 force
playsound minecraft:entity.player.attack.strong master @a ~ ~ ~ 3 0.6
damage @e[tag=!thp_caster,distance=..7] 4 minecraft:player_attack by @s
