particle minecraft:dust 1 0.15 0 3 ~6.5 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~6.5 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~6.11 ~0.3 ~2.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~6.11 ~0.2 ~2.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~4.98 ~0.3 ~4.18 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~4.98 ~0.2 ~4.18 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.25 ~0.3 ~5.63 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.25 ~0.2 ~5.63 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.13 ~0.3 ~6.4 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.13 ~0.2 ~6.4 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.13 ~0.3 ~6.4 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.13 ~0.2 ~6.4 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.25 ~0.3 ~5.63 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.25 ~0.2 ~5.63 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.98 ~0.3 ~4.18 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.98 ~0.2 ~4.18 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.11 ~0.3 ~2.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.11 ~0.2 ~2.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.5 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.5 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.11 ~0.3 ~-2.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.11 ~0.2 ~-2.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.98 ~0.3 ~-4.18 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.98 ~0.2 ~-4.18 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.25 ~0.3 ~-5.63 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.25 ~0.2 ~-5.63 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.13 ~0.3 ~-6.4 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.13 ~0.2 ~-6.4 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.13 ~0.3 ~-6.4 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.13 ~0.2 ~-6.4 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.25 ~0.3 ~-5.63 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.25 ~0.2 ~-5.63 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~4.98 ~0.3 ~-4.18 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~4.98 ~0.2 ~-4.18 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~6.11 ~0.3 ~-2.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~6.11 ~0.2 ~-2.22 0.3 0.2 0.3 0.05 1 force
