particle minecraft:dust 1 0.15 0 3 ~8.0 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~8.0 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.68 ~0.3 ~2.25 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.68 ~0.2 ~2.25 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~6.73 ~0.3 ~4.33 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~6.73 ~0.2 ~4.33 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~5.24 ~0.3 ~6.05 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~5.24 ~0.2 ~6.05 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.32 ~0.3 ~7.28 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.32 ~0.2 ~7.28 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.14 ~0.3 ~7.92 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.14 ~0.2 ~7.92 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.14 ~0.3 ~7.92 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.14 ~0.2 ~7.92 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.32 ~0.3 ~7.28 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.32 ~0.2 ~7.28 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-5.24 ~0.3 ~6.05 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-5.24 ~0.2 ~6.05 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.73 ~0.3 ~4.33 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.73 ~0.2 ~4.33 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-7.68 ~0.3 ~2.25 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-7.68 ~0.2 ~2.25 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.0 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.0 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-7.68 ~0.3 ~-2.25 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-7.68 ~0.2 ~-2.25 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.73 ~0.3 ~-4.33 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.73 ~0.2 ~-4.33 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-5.24 ~0.3 ~-6.05 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-5.24 ~0.2 ~-6.05 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.32 ~0.3 ~-7.28 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.32 ~0.2 ~-7.28 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.14 ~0.3 ~-7.92 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.14 ~0.2 ~-7.92 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.14 ~0.3 ~-7.92 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.14 ~0.2 ~-7.92 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.32 ~0.3 ~-7.28 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.32 ~0.2 ~-7.28 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~5.24 ~0.3 ~-6.05 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~5.24 ~0.2 ~-6.05 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~6.73 ~0.3 ~-4.33 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~6.73 ~0.2 ~-4.33 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.68 ~0.3 ~-2.25 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.68 ~0.2 ~-2.25 0.3 0.2 0.3 0.05 1 force
