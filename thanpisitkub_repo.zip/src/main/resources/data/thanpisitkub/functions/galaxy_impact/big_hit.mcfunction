particle minecraft:flash ^ ^1 ^3 0 0 0 0 1 force
particle minecraft:explosion_emitter ^ ^1 ^3 0 0 0 0 1 force
particle minecraft:dust 1 0.1 0 5 ^ ^1 ^3 3 3 3 0 120 force
particle minecraft:sonic_boom ^ ^1 ^3 0 0 0 0 1 force
particle minecraft:dust 0.3 0 0 4 ~ ~2 ~ 0.15 0 0.15 0 2 force
particle minecraft:electric_spark ~ ~2 ~ 0.6 0.3 0.6 0.2 2 force
particle minecraft:dust 0.3 0 0 4 ~ ~4 ~ 0.15 0 0.15 0 2 force
particle minecraft:electric_spark ~ ~4 ~ 0.6 0.3 0.6 0.2 2 force
particle minecraft:dust 0.3 0 0 4 ~ ~6 ~ 0.15 0 0.15 0 2 force
particle minecraft:electric_spark ~ ~6 ~ 0.6 0.3 0.6 0.2 2 force
particle minecraft:dust 0.3 0 0 4 ~ ~8 ~ 0.15 0 0.15 0 2 force
particle minecraft:electric_spark ~ ~8 ~ 0.6 0.3 0.6 0.2 2 force
particle minecraft:dust 0.3 0 0 4 ~ ~10 ~ 0.15 0 0.15 0 2 force
particle minecraft:electric_spark ~ ~10 ~ 0.6 0.3 0.6 0.2 2 force
particle minecraft:dust 0.3 0 0 4 ~ ~12 ~ 0.15 0 0.15 0 2 force
particle minecraft:electric_spark ~ ~12 ~ 0.6 0.3 0.6 0.2 2 force
particle minecraft:dust 0.3 0 0 4 ~ ~14 ~ 0.15 0 0.15 0 2 force
particle minecraft:electric_spark ~ ~14 ~ 0.6 0.3 0.6 0.2 2 force
particle minecraft:dust 0.3 0 0 4 ~ ~16 ~ 0.15 0 0.15 0 2 force
particle minecraft:electric_spark ~ ~16 ~ 0.6 0.3 0.6 0.2 2 force
particle minecraft:dust 0.3 0 0 4 ~ ~18 ~ 0.15 0 0.15 0 2 force
particle minecraft:electric_spark ~ ~18 ~ 0.6 0.3 0.6 0.2 2 force
particle minecraft:dust 0.3 0 0 4 ~ ~20 ~ 0.15 0 0.15 0 2 force
particle minecraft:electric_spark ~ ~20 ~ 0.6 0.3 0.6 0.2 2 force
particle minecraft:dust 0.3 0 0 4 ~ ~22 ~ 0.15 0 0.15 0 2 force
particle minecraft:electric_spark ~ ~22 ~ 0.6 0.3 0.6 0.2 2 force
particle minecraft:dust 0.3 0 0 4 ~ ~24 ~ 0.15 0 0.15 0 2 force
particle minecraft:electric_spark ~ ~24 ~ 0.6 0.3 0.6 0.2 2 force
particle minecraft:dust 0.3 0 0 4 ~ ~26 ~ 0.15 0 0.15 0 2 force
particle minecraft:electric_spark ~ ~26 ~ 0.6 0.3 0.6 0.2 2 force
particle minecraft:dust 0.3 0 0 4 ~ ~28 ~ 0.15 0 0.15 0 2 force
particle minecraft:electric_spark ~ ~28 ~ 0.6 0.3 0.6 0.2 2 force
particle minecraft:dust 0.3 0 0 4 ~ ~30 ~ 0.15 0 0.15 0 2 force
particle minecraft:electric_spark ~ ~30 ~ 0.6 0.3 0.6 0.2 2 force
particle minecraft:dust 0.3 0 0 4 ~ ~32 ~ 0.15 0 0.15 0 2 force
particle minecraft:electric_spark ~ ~32 ~ 0.6 0.3 0.6 0.2 2 force
particle minecraft:dust 0.3 0 0 4 ~ ~34 ~ 0.15 0 0.15 0 2 force
particle minecraft:electric_spark ~ ~34 ~ 0.6 0.3 0.6 0.2 2 force
playsound minecraft:entity.generic.explode master @a ~ ~ ~ 6 0.5
playsound minecraft:entity.lightning_bolt.thunder master @a ~ ~ ~ 6 0.6
damage @e[tag=!thp_caster,distance=..14] 20 minecraft:player_attack by @s
