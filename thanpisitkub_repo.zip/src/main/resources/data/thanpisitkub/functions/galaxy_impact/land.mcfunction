scoreboard players set @s thp_gi 1000
particle minecraft:flash ~ ~1 ~ 0 0 0 0 1 force
particle minecraft:explosion_emitter ~ ~ ~ 3 0.2 3 0 6 force
particle minecraft:dust 1 0.1 0 5 ~ ~0.5 ~ 3 0.4 3 0 120 force
particle minecraft:sonic_boom ~ ~1 ~ 0 0 0 0 1 force
execute rotated 0 0 positioned ^ ^ ^2 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 0 0 positioned ^ ^ ^2 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 0 0 positioned ^ ^ ^4 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 0 0 positioned ^ ^ ^4 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 0 0 positioned ^ ^ ^6 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 0 0 positioned ^ ^ ^6 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 0 0 positioned ^ ^ ^8 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 0 0 positioned ^ ^ ^8 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 0 0 positioned ^ ^ ^10 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 0 0 positioned ^ ^ ^10 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 0 0 positioned ^ ^ ^12 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 0 0 positioned ^ ^ ^12 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 0 0 positioned ^ ^ ^14 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 0 0 positioned ^ ^ ^14 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 0 0 positioned ^ ^ ^16 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 0 0 positioned ^ ^ ^16 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 0 0 positioned ^ ^ ^18 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 0 0 positioned ^ ^ ^18 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 0 0 positioned ^ ^ ^20 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 0 0 positioned ^ ^ ^20 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 0 0 positioned ^ ^ ^22 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 0 0 positioned ^ ^ ^22 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 0 0 positioned ^ ^ ^24 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 0 0 positioned ^ ^ ^24 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 45 0 positioned ^ ^ ^2 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 45 0 positioned ^ ^ ^2 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 45 0 positioned ^ ^ ^4 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 45 0 positioned ^ ^ ^4 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 45 0 positioned ^ ^ ^6 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 45 0 positioned ^ ^ ^6 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 45 0 positioned ^ ^ ^8 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 45 0 positioned ^ ^ ^8 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 45 0 positioned ^ ^ ^10 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 45 0 positioned ^ ^ ^10 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 45 0 positioned ^ ^ ^12 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 45 0 positioned ^ ^ ^12 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 45 0 positioned ^ ^ ^14 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 45 0 positioned ^ ^ ^14 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 45 0 positioned ^ ^ ^16 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 45 0 positioned ^ ^ ^16 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 45 0 positioned ^ ^ ^18 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 45 0 positioned ^ ^ ^18 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 45 0 positioned ^ ^ ^20 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 45 0 positioned ^ ^ ^20 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 45 0 positioned ^ ^ ^22 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 45 0 positioned ^ ^ ^22 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 45 0 positioned ^ ^ ^24 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 45 0 positioned ^ ^ ^24 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 90 0 positioned ^ ^ ^2 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 90 0 positioned ^ ^ ^2 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 90 0 positioned ^ ^ ^4 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 90 0 positioned ^ ^ ^4 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 90 0 positioned ^ ^ ^6 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 90 0 positioned ^ ^ ^6 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 90 0 positioned ^ ^ ^8 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 90 0 positioned ^ ^ ^8 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 90 0 positioned ^ ^ ^10 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 90 0 positioned ^ ^ ^10 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 90 0 positioned ^ ^ ^12 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 90 0 positioned ^ ^ ^12 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 90 0 positioned ^ ^ ^14 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 90 0 positioned ^ ^ ^14 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 90 0 positioned ^ ^ ^16 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 90 0 positioned ^ ^ ^16 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 90 0 positioned ^ ^ ^18 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 90 0 positioned ^ ^ ^18 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 90 0 positioned ^ ^ ^20 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 90 0 positioned ^ ^ ^20 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 90 0 positioned ^ ^ ^22 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 90 0 positioned ^ ^ ^22 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 90 0 positioned ^ ^ ^24 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 90 0 positioned ^ ^ ^24 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 135 0 positioned ^ ^ ^2 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 135 0 positioned ^ ^ ^2 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 135 0 positioned ^ ^ ^4 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 135 0 positioned ^ ^ ^4 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 135 0 positioned ^ ^ ^6 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 135 0 positioned ^ ^ ^6 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 135 0 positioned ^ ^ ^8 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 135 0 positioned ^ ^ ^8 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 135 0 positioned ^ ^ ^10 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 135 0 positioned ^ ^ ^10 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 135 0 positioned ^ ^ ^12 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 135 0 positioned ^ ^ ^12 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 135 0 positioned ^ ^ ^14 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 135 0 positioned ^ ^ ^14 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 135 0 positioned ^ ^ ^16 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 135 0 positioned ^ ^ ^16 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 135 0 positioned ^ ^ ^18 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 135 0 positioned ^ ^ ^18 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 135 0 positioned ^ ^ ^20 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 135 0 positioned ^ ^ ^20 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 135 0 positioned ^ ^ ^22 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 135 0 positioned ^ ^ ^22 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 135 0 positioned ^ ^ ^24 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 135 0 positioned ^ ^ ^24 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 180 0 positioned ^ ^ ^2 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 180 0 positioned ^ ^ ^2 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 180 0 positioned ^ ^ ^4 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 180 0 positioned ^ ^ ^4 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 180 0 positioned ^ ^ ^6 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 180 0 positioned ^ ^ ^6 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 180 0 positioned ^ ^ ^8 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 180 0 positioned ^ ^ ^8 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 180 0 positioned ^ ^ ^10 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 180 0 positioned ^ ^ ^10 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 180 0 positioned ^ ^ ^12 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 180 0 positioned ^ ^ ^12 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 180 0 positioned ^ ^ ^14 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 180 0 positioned ^ ^ ^14 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 180 0 positioned ^ ^ ^16 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 180 0 positioned ^ ^ ^16 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 180 0 positioned ^ ^ ^18 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 180 0 positioned ^ ^ ^18 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 180 0 positioned ^ ^ ^20 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 180 0 positioned ^ ^ ^20 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 180 0 positioned ^ ^ ^22 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 180 0 positioned ^ ^ ^22 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 180 0 positioned ^ ^ ^24 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 180 0 positioned ^ ^ ^24 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 225 0 positioned ^ ^ ^2 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 225 0 positioned ^ ^ ^2 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 225 0 positioned ^ ^ ^4 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 225 0 positioned ^ ^ ^4 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 225 0 positioned ^ ^ ^6 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 225 0 positioned ^ ^ ^6 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 225 0 positioned ^ ^ ^8 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 225 0 positioned ^ ^ ^8 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 225 0 positioned ^ ^ ^10 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 225 0 positioned ^ ^ ^10 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 225 0 positioned ^ ^ ^12 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 225 0 positioned ^ ^ ^12 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 225 0 positioned ^ ^ ^14 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 225 0 positioned ^ ^ ^14 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 225 0 positioned ^ ^ ^16 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 225 0 positioned ^ ^ ^16 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 225 0 positioned ^ ^ ^18 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 225 0 positioned ^ ^ ^18 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 225 0 positioned ^ ^ ^20 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 225 0 positioned ^ ^ ^20 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 225 0 positioned ^ ^ ^22 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 225 0 positioned ^ ^ ^22 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 225 0 positioned ^ ^ ^24 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 225 0 positioned ^ ^ ^24 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 270 0 positioned ^ ^ ^2 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 270 0 positioned ^ ^ ^2 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 270 0 positioned ^ ^ ^4 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 270 0 positioned ^ ^ ^4 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 270 0 positioned ^ ^ ^6 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 270 0 positioned ^ ^ ^6 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 270 0 positioned ^ ^ ^8 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 270 0 positioned ^ ^ ^8 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 270 0 positioned ^ ^ ^10 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 270 0 positioned ^ ^ ^10 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 270 0 positioned ^ ^ ^12 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 270 0 positioned ^ ^ ^12 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 270 0 positioned ^ ^ ^14 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 270 0 positioned ^ ^ ^14 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 270 0 positioned ^ ^ ^16 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 270 0 positioned ^ ^ ^16 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 270 0 positioned ^ ^ ^18 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 270 0 positioned ^ ^ ^18 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 270 0 positioned ^ ^ ^20 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 270 0 positioned ^ ^ ^20 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 270 0 positioned ^ ^ ^22 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 270 0 positioned ^ ^ ^22 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 270 0 positioned ^ ^ ^24 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 270 0 positioned ^ ^ ^24 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 315 0 positioned ^ ^ ^2 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 315 0 positioned ^ ^ ^2 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 315 0 positioned ^ ^ ^4 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 315 0 positioned ^ ^ ^4 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 315 0 positioned ^ ^ ^6 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 315 0 positioned ^ ^ ^6 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 315 0 positioned ^ ^ ^8 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 315 0 positioned ^ ^ ^8 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 315 0 positioned ^ ^ ^10 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 315 0 positioned ^ ^ ^10 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 315 0 positioned ^ ^ ^12 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 315 0 positioned ^ ^ ^12 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 315 0 positioned ^ ^ ^14 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 315 0 positioned ^ ^ ^14 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 315 0 positioned ^ ^ ^16 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 315 0 positioned ^ ^ ^16 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 315 0 positioned ^ ^ ^18 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 315 0 positioned ^ ^ ^18 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 315 0 positioned ^ ^ ^20 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 315 0 positioned ^ ^ ^20 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 315 0 positioned ^ ^ ^22 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 315 0 positioned ^ ^ ^22 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
execute rotated 315 0 positioned ^ ^ ^24 run particle minecraft:dust 0.3 0 0 3 ~ ~0.2 ~ 0.4 0.1 0.4 0 5 force
execute rotated 315 0 positioned ^ ^ ^24 run particle minecraft:electric_spark ~ ~0.4 ~ 0.4 0.3 0.4 0.3 3 force
playsound minecraft:entity.generic.explode master @a ~ ~ ~ 8 0.5
playsound minecraft:entity.lightning_bolt.thunder master @a ~ ~ ~ 8 0.5
damage @e[tag=!thp_caster,distance=..28] 30 minecraft:player_attack by @s
