particle minecraft:dust 1 0.15 0 3 ~23.0 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~23.0 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~22.89 ~0.3 ~2.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~22.89 ~0.2 ~2.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~22.57 ~0.3 ~4.42 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~22.57 ~0.2 ~4.42 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~22.04 ~0.3 ~6.58 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~22.04 ~0.2 ~6.58 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~21.3 ~0.3 ~8.67 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~21.3 ~0.2 ~8.67 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~20.37 ~0.3 ~10.69 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~20.37 ~0.2 ~10.69 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~19.24 ~0.3 ~12.6 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~19.24 ~0.2 ~12.6 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~17.93 ~0.3 ~14.4 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~17.93 ~0.2 ~14.4 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~16.46 ~0.3 ~16.07 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~16.46 ~0.2 ~16.07 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~14.83 ~0.3 ~17.58 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~14.83 ~0.2 ~17.58 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.07 ~0.3 ~18.93 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.07 ~0.2 ~18.93 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~11.18 ~0.3 ~20.1 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.18 ~0.2 ~20.1 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.19 ~0.3 ~21.09 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.19 ~0.2 ~21.09 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.11 ~0.3 ~21.87 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.11 ~0.2 ~21.87 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~4.96 ~0.3 ~22.46 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~4.96 ~0.2 ~22.46 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~2.77 ~0.3 ~22.83 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~2.77 ~0.2 ~22.83 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~0.56 ~0.3 ~22.99 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~0.56 ~0.2 ~22.99 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.67 ~0.3 ~22.94 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.67 ~0.2 ~22.94 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.87 ~0.3 ~22.67 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.87 ~0.2 ~22.67 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.04 ~0.3 ~22.19 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.04 ~0.2 ~22.19 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.16 ~0.3 ~21.51 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.16 ~0.2 ~21.51 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.19 ~0.3 ~20.62 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.19 ~0.2 ~20.62 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-12.14 ~0.3 ~19.54 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-12.14 ~0.2 ~19.54 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.96 ~0.3 ~18.28 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.96 ~0.2 ~18.28 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.66 ~0.3 ~16.84 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.66 ~0.2 ~16.84 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.22 ~0.3 ~15.25 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.22 ~0.2 ~15.25 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-18.61 ~0.3 ~13.52 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-18.61 ~0.2 ~13.52 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-19.83 ~0.3 ~11.66 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-19.83 ~0.2 ~11.66 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-20.86 ~0.3 ~9.69 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-20.86 ~0.2 ~9.69 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-21.7 ~0.3 ~7.63 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-21.7 ~0.2 ~7.63 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-22.33 ~0.3 ~5.5 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-22.33 ~0.2 ~5.5 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-22.76 ~0.3 ~3.32 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-22.76 ~0.2 ~3.32 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-22.97 ~0.3 ~1.11 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-22.97 ~0.2 ~1.11 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-22.97 ~0.3 ~-1.11 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-22.97 ~0.2 ~-1.11 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-22.76 ~0.3 ~-3.32 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-22.76 ~0.2 ~-3.32 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-22.33 ~0.3 ~-5.5 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-22.33 ~0.2 ~-5.5 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-21.7 ~0.3 ~-7.63 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-21.7 ~0.2 ~-7.63 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-20.86 ~0.3 ~-9.69 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-20.86 ~0.2 ~-9.69 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-19.83 ~0.3 ~-11.66 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-19.83 ~0.2 ~-11.66 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-18.61 ~0.3 ~-13.52 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-18.61 ~0.2 ~-13.52 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.22 ~0.3 ~-15.25 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.22 ~0.2 ~-15.25 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.66 ~0.3 ~-16.84 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.66 ~0.2 ~-16.84 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.96 ~0.3 ~-18.28 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.96 ~0.2 ~-18.28 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-12.14 ~0.3 ~-19.54 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-12.14 ~0.2 ~-19.54 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.19 ~0.3 ~-20.62 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.19 ~0.2 ~-20.62 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.16 ~0.3 ~-21.51 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.16 ~0.2 ~-21.51 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.04 ~0.3 ~-22.19 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.04 ~0.2 ~-22.19 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.87 ~0.3 ~-22.67 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.87 ~0.2 ~-22.67 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.67 ~0.3 ~-22.94 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.67 ~0.2 ~-22.94 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~0.56 ~0.3 ~-22.99 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~0.56 ~0.2 ~-22.99 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~2.77 ~0.3 ~-22.83 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~2.77 ~0.2 ~-22.83 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~4.96 ~0.3 ~-22.46 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~4.96 ~0.2 ~-22.46 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.11 ~0.3 ~-21.87 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.11 ~0.2 ~-21.87 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.19 ~0.3 ~-21.09 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.19 ~0.2 ~-21.09 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~11.18 ~0.3 ~-20.1 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.18 ~0.2 ~-20.1 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.07 ~0.3 ~-18.93 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.07 ~0.2 ~-18.93 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~14.83 ~0.3 ~-17.58 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~14.83 ~0.2 ~-17.58 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~16.46 ~0.3 ~-16.07 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~16.46 ~0.2 ~-16.07 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~17.93 ~0.3 ~-14.4 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~17.93 ~0.2 ~-14.4 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~19.24 ~0.3 ~-12.6 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~19.24 ~0.2 ~-12.6 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~20.37 ~0.3 ~-10.69 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~20.37 ~0.2 ~-10.69 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~21.3 ~0.3 ~-8.67 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~21.3 ~0.2 ~-8.67 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~22.04 ~0.3 ~-6.58 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~22.04 ~0.2 ~-6.58 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~22.57 ~0.3 ~-4.42 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~22.57 ~0.2 ~-4.42 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~22.89 ~0.3 ~-2.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~22.89 ~0.2 ~-2.22 0.3 0.2 0.3 0.05 1 force
