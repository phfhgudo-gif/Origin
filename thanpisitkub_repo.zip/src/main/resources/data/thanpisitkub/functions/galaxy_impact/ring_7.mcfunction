particle minecraft:dust 1 0.15 0 3 ~12.5 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~12.5 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~12.3 ~0.3 ~2.23 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~12.3 ~0.2 ~2.23 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~11.7 ~0.3 ~4.39 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.7 ~0.2 ~4.39 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~10.73 ~0.3 ~6.41 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~10.73 ~0.2 ~6.41 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.41 ~0.3 ~8.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.41 ~0.2 ~8.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.79 ~0.3 ~9.77 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.79 ~0.2 ~9.77 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~5.92 ~0.3 ~11.01 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~5.92 ~0.2 ~11.01 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.86 ~0.3 ~11.89 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.86 ~0.2 ~11.89 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.68 ~0.3 ~12.39 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.68 ~0.2 ~12.39 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-0.56 ~0.3 ~12.49 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-0.56 ~0.2 ~12.49 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.78 ~0.3 ~12.19 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.78 ~0.2 ~12.19 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.91 ~0.3 ~11.49 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.91 ~0.2 ~11.49 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.89 ~0.3 ~10.43 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.89 ~0.2 ~10.43 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.64 ~0.3 ~9.03 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.64 ~0.2 ~9.03 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.11 ~0.3 ~7.35 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.11 ~0.2 ~7.35 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-11.26 ~0.3 ~5.42 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-11.26 ~0.2 ~5.42 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-12.05 ~0.3 ~3.33 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-12.05 ~0.2 ~3.33 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-12.45 ~0.3 ~1.12 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-12.45 ~0.2 ~1.12 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-12.45 ~0.3 ~-1.12 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-12.45 ~0.2 ~-1.12 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-12.05 ~0.3 ~-3.33 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-12.05 ~0.2 ~-3.33 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-11.26 ~0.3 ~-5.42 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-11.26 ~0.2 ~-5.42 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.11 ~0.3 ~-7.35 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.11 ~0.2 ~-7.35 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.64 ~0.3 ~-9.03 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.64 ~0.2 ~-9.03 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.89 ~0.3 ~-10.43 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.89 ~0.2 ~-10.43 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.91 ~0.3 ~-11.49 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.91 ~0.2 ~-11.49 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.78 ~0.3 ~-12.19 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.78 ~0.2 ~-12.19 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-0.56 ~0.3 ~-12.49 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-0.56 ~0.2 ~-12.49 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.68 ~0.3 ~-12.39 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.68 ~0.2 ~-12.39 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.86 ~0.3 ~-11.89 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.86 ~0.2 ~-11.89 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~5.92 ~0.3 ~-11.01 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~5.92 ~0.2 ~-11.01 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.79 ~0.3 ~-9.77 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.79 ~0.2 ~-9.77 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.41 ~0.3 ~-8.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.41 ~0.2 ~-8.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~10.73 ~0.3 ~-6.41 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~10.73 ~0.2 ~-6.41 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~11.7 ~0.3 ~-4.39 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.7 ~0.2 ~-4.39 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~12.3 ~0.3 ~-2.23 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~12.3 ~0.2 ~-2.23 0.3 0.2 0.3 0.05 1 force
