particle minecraft:dust 1 0.15 0 3 ~18.5 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~18.5 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~18.37 ~0.3 ~2.23 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~18.37 ~0.2 ~2.23 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~17.96 ~0.3 ~4.43 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~17.96 ~0.2 ~4.43 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~17.3 ~0.3 ~6.56 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~17.3 ~0.2 ~6.56 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~16.38 ~0.3 ~8.6 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~16.38 ~0.2 ~8.6 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~15.23 ~0.3 ~10.51 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~15.23 ~0.2 ~10.51 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.85 ~0.3 ~12.27 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.85 ~0.2 ~12.27 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~12.27 ~0.3 ~13.85 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~12.27 ~0.2 ~13.85 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~10.51 ~0.3 ~15.23 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~10.51 ~0.2 ~15.23 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~8.6 ~0.3 ~16.38 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~8.6 ~0.2 ~16.38 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~6.56 ~0.3 ~17.3 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~6.56 ~0.2 ~17.3 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~4.43 ~0.3 ~17.96 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~4.43 ~0.2 ~17.96 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~2.23 ~0.3 ~18.37 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~2.23 ~0.2 ~18.37 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-0.0 ~0.3 ~18.5 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-0.0 ~0.2 ~18.5 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.23 ~0.3 ~18.37 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.23 ~0.2 ~18.37 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.43 ~0.3 ~17.96 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.43 ~0.2 ~17.96 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.56 ~0.3 ~17.3 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.56 ~0.2 ~17.3 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.6 ~0.3 ~16.38 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.6 ~0.2 ~16.38 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.51 ~0.3 ~15.23 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.51 ~0.2 ~15.23 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-12.27 ~0.3 ~13.85 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-12.27 ~0.2 ~13.85 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.85 ~0.3 ~12.27 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.85 ~0.2 ~12.27 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.23 ~0.3 ~10.51 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.23 ~0.2 ~10.51 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-16.38 ~0.3 ~8.6 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-16.38 ~0.2 ~8.6 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.3 ~0.3 ~6.56 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.3 ~0.2 ~6.56 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.96 ~0.3 ~4.43 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.96 ~0.2 ~4.43 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-18.37 ~0.3 ~2.23 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-18.37 ~0.2 ~2.23 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-18.5 ~0.3 ~-0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-18.5 ~0.2 ~-0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-18.37 ~0.3 ~-2.23 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-18.37 ~0.2 ~-2.23 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.96 ~0.3 ~-4.43 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.96 ~0.2 ~-4.43 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.3 ~0.3 ~-6.56 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.3 ~0.2 ~-6.56 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-16.38 ~0.3 ~-8.6 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-16.38 ~0.2 ~-8.6 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.23 ~0.3 ~-10.51 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.23 ~0.2 ~-10.51 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.85 ~0.3 ~-12.27 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.85 ~0.2 ~-12.27 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-12.27 ~0.3 ~-13.85 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-12.27 ~0.2 ~-13.85 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.51 ~0.3 ~-15.23 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.51 ~0.2 ~-15.23 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.6 ~0.3 ~-16.38 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.6 ~0.2 ~-16.38 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.56 ~0.3 ~-17.3 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.56 ~0.2 ~-17.3 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.43 ~0.3 ~-17.96 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.43 ~0.2 ~-17.96 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.23 ~0.3 ~-18.37 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.23 ~0.2 ~-18.37 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-0.0 ~0.3 ~-18.5 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-0.0 ~0.2 ~-18.5 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~2.23 ~0.3 ~-18.37 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~2.23 ~0.2 ~-18.37 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~4.43 ~0.3 ~-17.96 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~4.43 ~0.2 ~-17.96 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~6.56 ~0.3 ~-17.3 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~6.56 ~0.2 ~-17.3 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~8.6 ~0.3 ~-16.38 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~8.6 ~0.2 ~-16.38 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~10.51 ~0.3 ~-15.23 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~10.51 ~0.2 ~-15.23 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~12.27 ~0.3 ~-13.85 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~12.27 ~0.2 ~-13.85 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.85 ~0.3 ~-12.27 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.85 ~0.2 ~-12.27 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~15.23 ~0.3 ~-10.51 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~15.23 ~0.2 ~-10.51 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~16.38 ~0.3 ~-8.6 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~16.38 ~0.2 ~-8.6 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~17.3 ~0.3 ~-6.56 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~17.3 ~0.2 ~-6.56 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~17.96 ~0.3 ~-4.43 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~17.96 ~0.2 ~-4.43 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~18.37 ~0.3 ~-2.23 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~18.37 ~0.2 ~-2.23 0.3 0.2 0.3 0.05 1 force
