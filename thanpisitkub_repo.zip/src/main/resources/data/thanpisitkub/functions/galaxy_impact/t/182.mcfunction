execute rotated ~ 0 run particle thanpisitkub:garp_ult1_1 ^0.0 ^11.42 ^1.0 0 0 0 0 1 force
