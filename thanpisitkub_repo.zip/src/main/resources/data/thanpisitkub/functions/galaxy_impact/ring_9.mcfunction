particle minecraft:dust 1 0.15 0 3 ~15.5 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~15.5 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~15.34 ~0.3 ~2.21 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~15.34 ~0.2 ~2.21 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~14.87 ~0.3 ~4.37 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~14.87 ~0.2 ~4.37 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~14.1 ~0.3 ~6.44 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~14.1 ~0.2 ~6.44 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.04 ~0.3 ~8.38 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.04 ~0.2 ~8.38 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~11.71 ~0.3 ~10.15 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.71 ~0.2 ~10.15 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~10.15 ~0.3 ~11.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~10.15 ~0.2 ~11.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~8.38 ~0.3 ~13.04 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~8.38 ~0.2 ~13.04 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~6.44 ~0.3 ~14.1 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~6.44 ~0.2 ~14.1 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~4.37 ~0.3 ~14.87 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~4.37 ~0.2 ~14.87 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~2.21 ~0.3 ~15.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~2.21 ~0.2 ~15.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~0.0 ~0.3 ~15.5 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~0.0 ~0.2 ~15.5 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.21 ~0.3 ~15.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.21 ~0.2 ~15.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.37 ~0.3 ~14.87 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.37 ~0.2 ~14.87 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.44 ~0.3 ~14.1 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.44 ~0.2 ~14.1 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.38 ~0.3 ~13.04 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.38 ~0.2 ~13.04 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.15 ~0.3 ~11.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.15 ~0.2 ~11.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-11.71 ~0.3 ~10.15 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-11.71 ~0.2 ~10.15 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.04 ~0.3 ~8.38 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.04 ~0.2 ~8.38 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-14.1 ~0.3 ~6.44 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-14.1 ~0.2 ~6.44 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-14.87 ~0.3 ~4.37 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-14.87 ~0.2 ~4.37 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.34 ~0.3 ~2.21 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.34 ~0.2 ~2.21 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.5 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.5 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.34 ~0.3 ~-2.21 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.34 ~0.2 ~-2.21 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-14.87 ~0.3 ~-4.37 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-14.87 ~0.2 ~-4.37 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-14.1 ~0.3 ~-6.44 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-14.1 ~0.2 ~-6.44 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.04 ~0.3 ~-8.38 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.04 ~0.2 ~-8.38 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-11.71 ~0.3 ~-10.15 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-11.71 ~0.2 ~-10.15 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.15 ~0.3 ~-11.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.15 ~0.2 ~-11.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.38 ~0.3 ~-13.04 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.38 ~0.2 ~-13.04 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.44 ~0.3 ~-14.1 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.44 ~0.2 ~-14.1 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.37 ~0.3 ~-14.87 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.37 ~0.2 ~-14.87 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.21 ~0.3 ~-15.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.21 ~0.2 ~-15.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-0.0 ~0.3 ~-15.5 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-0.0 ~0.2 ~-15.5 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~2.21 ~0.3 ~-15.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~2.21 ~0.2 ~-15.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~4.37 ~0.3 ~-14.87 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~4.37 ~0.2 ~-14.87 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~6.44 ~0.3 ~-14.1 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~6.44 ~0.2 ~-14.1 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~8.38 ~0.3 ~-13.04 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~8.38 ~0.2 ~-13.04 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~10.15 ~0.3 ~-11.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~10.15 ~0.2 ~-11.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~11.71 ~0.3 ~-10.15 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.71 ~0.2 ~-10.15 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.04 ~0.3 ~-8.38 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.04 ~0.2 ~-8.38 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~14.1 ~0.3 ~-6.44 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~14.1 ~0.2 ~-6.44 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~14.87 ~0.3 ~-4.37 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~14.87 ~0.2 ~-4.37 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~15.34 ~0.3 ~-2.21 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~15.34 ~0.2 ~-2.21 0.3 0.2 0.3 0.05 1 force
