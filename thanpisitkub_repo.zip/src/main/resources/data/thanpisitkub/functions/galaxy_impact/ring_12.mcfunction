particle minecraft:dust 1 0.15 0 3 ~20.0 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~20.0 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~19.88 ~0.3 ~2.2 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~19.88 ~0.2 ~2.2 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~19.52 ~0.3 ~4.37 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~19.52 ~0.2 ~4.37 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~18.92 ~0.3 ~6.49 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~18.92 ~0.2 ~6.49 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~18.09 ~0.3 ~8.54 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~18.09 ~0.2 ~8.54 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~17.04 ~0.3 ~10.47 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~17.04 ~0.2 ~10.47 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~15.78 ~0.3 ~12.28 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~15.78 ~0.2 ~12.28 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~14.34 ~0.3 ~13.95 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~14.34 ~0.2 ~13.95 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~12.71 ~0.3 ~15.44 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~12.71 ~0.2 ~15.44 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~10.94 ~0.3 ~16.74 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~10.94 ~0.2 ~16.74 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.03 ~0.3 ~17.85 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.03 ~0.2 ~17.85 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.01 ~0.3 ~18.73 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.01 ~0.2 ~18.73 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~4.91 ~0.3 ~19.39 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~4.91 ~0.2 ~19.39 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~2.75 ~0.3 ~19.81 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~2.75 ~0.2 ~19.81 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~0.55 ~0.3 ~19.99 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~0.55 ~0.2 ~19.99 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.65 ~0.3 ~19.93 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.65 ~0.2 ~19.93 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.83 ~0.3 ~19.63 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.83 ~0.2 ~19.63 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-5.97 ~0.3 ~19.09 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-5.97 ~0.2 ~19.09 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.03 ~0.3 ~18.32 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.03 ~0.2 ~18.32 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.0 ~0.3 ~17.32 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.0 ~0.2 ~17.32 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-11.84 ~0.3 ~16.12 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-11.84 ~0.2 ~16.12 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.55 ~0.3 ~14.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.55 ~0.2 ~14.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.08 ~0.3 ~13.14 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.08 ~0.2 ~13.14 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-16.44 ~0.3 ~11.4 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-16.44 ~0.2 ~11.4 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.59 ~0.3 ~9.52 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.59 ~0.2 ~9.52 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-18.53 ~0.3 ~7.53 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-18.53 ~0.2 ~7.53 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-19.25 ~0.3 ~5.44 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-19.25 ~0.2 ~5.44 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-19.73 ~0.3 ~3.29 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-19.73 ~0.2 ~3.29 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-19.97 ~0.3 ~1.1 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-19.97 ~0.2 ~1.1 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-19.97 ~0.3 ~-1.1 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-19.97 ~0.2 ~-1.1 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-19.73 ~0.3 ~-3.29 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-19.73 ~0.2 ~-3.29 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-19.25 ~0.3 ~-5.44 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-19.25 ~0.2 ~-5.44 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-18.53 ~0.3 ~-7.53 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-18.53 ~0.2 ~-7.53 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.59 ~0.3 ~-9.52 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.59 ~0.2 ~-9.52 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-16.44 ~0.3 ~-11.4 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-16.44 ~0.2 ~-11.4 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.08 ~0.3 ~-13.14 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.08 ~0.2 ~-13.14 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.55 ~0.3 ~-14.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.55 ~0.2 ~-14.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-11.84 ~0.3 ~-16.12 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-11.84 ~0.2 ~-16.12 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.0 ~0.3 ~-17.32 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.0 ~0.2 ~-17.32 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.03 ~0.3 ~-18.32 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.03 ~0.2 ~-18.32 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-5.97 ~0.3 ~-19.09 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-5.97 ~0.2 ~-19.09 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.83 ~0.3 ~-19.63 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.83 ~0.2 ~-19.63 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.65 ~0.3 ~-19.93 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.65 ~0.2 ~-19.93 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~0.55 ~0.3 ~-19.99 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~0.55 ~0.2 ~-19.99 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~2.75 ~0.3 ~-19.81 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~2.75 ~0.2 ~-19.81 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~4.91 ~0.3 ~-19.39 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~4.91 ~0.2 ~-19.39 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.01 ~0.3 ~-18.73 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.01 ~0.2 ~-18.73 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.03 ~0.3 ~-17.85 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.03 ~0.2 ~-17.85 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~10.94 ~0.3 ~-16.74 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~10.94 ~0.2 ~-16.74 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~12.71 ~0.3 ~-15.44 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~12.71 ~0.2 ~-15.44 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~14.34 ~0.3 ~-13.95 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~14.34 ~0.2 ~-13.95 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~15.78 ~0.3 ~-12.28 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~15.78 ~0.2 ~-12.28 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~17.04 ~0.3 ~-10.47 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~17.04 ~0.2 ~-10.47 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~18.09 ~0.3 ~-8.54 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~18.09 ~0.2 ~-8.54 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~18.92 ~0.3 ~-6.49 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~18.92 ~0.2 ~-6.49 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~19.52 ~0.3 ~-4.37 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~19.52 ~0.2 ~-4.37 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~19.88 ~0.3 ~-2.2 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~19.88 ~0.2 ~-2.2 0.3 0.2 0.3 0.05 1 force
