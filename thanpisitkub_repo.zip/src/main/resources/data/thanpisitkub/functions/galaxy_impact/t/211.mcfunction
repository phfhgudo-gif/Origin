execute rotated ~ 0 run particle thanpisitkub:garp_ult1_1_2 ^0.0 ^14.26 ^1.0 0 0 0 0 1 force
