particle minecraft:flame ~ ~1 ~ 0.5 0.9 0.5 0.06 4 force
particle minecraft:dust 1 0.1 0 2.5 ~ ~1 ~ 0.8 1.1 0.8 0 5 force
particle minecraft:dust 0.2 0 0 3 ~ ~1 ~ 1.2 1.4 1.2 0 3 force
particle minecraft:electric_spark ~ ~1 ~ 1 1.2 1 0.4 2 force
