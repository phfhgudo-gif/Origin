particle minecraft:dust 1 0.15 0 3 ~21.5 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~21.5 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~21.39 ~0.3 ~2.21 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~21.39 ~0.2 ~2.21 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~21.05 ~0.3 ~4.4 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~21.05 ~0.2 ~4.4 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~20.48 ~0.3 ~6.54 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~20.48 ~0.2 ~6.54 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~19.7 ~0.3 ~8.61 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~19.7 ~0.2 ~8.61 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~18.71 ~0.3 ~10.59 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~18.71 ~0.2 ~10.59 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~17.52 ~0.3 ~12.46 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~17.52 ~0.2 ~12.46 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~16.15 ~0.3 ~14.19 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~16.15 ~0.2 ~14.19 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~14.6 ~0.3 ~15.78 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~14.6 ~0.2 ~15.78 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~12.9 ~0.3 ~17.2 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~12.9 ~0.2 ~17.2 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~11.07 ~0.3 ~18.43 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.07 ~0.2 ~18.43 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.11 ~0.3 ~19.47 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.11 ~0.2 ~19.47 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.06 ~0.3 ~20.31 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.06 ~0.2 ~20.31 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~4.94 ~0.3 ~20.93 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~4.94 ~0.2 ~20.93 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~2.76 ~0.3 ~21.32 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~2.76 ~0.2 ~21.32 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~0.55 ~0.3 ~21.49 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~0.55 ~0.2 ~21.49 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.66 ~0.3 ~21.44 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.66 ~0.2 ~21.44 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.85 ~0.3 ~21.15 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.85 ~0.2 ~21.15 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.01 ~0.3 ~20.64 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.01 ~0.2 ~20.64 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.1 ~0.3 ~19.92 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.1 ~0.2 ~19.92 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.1 ~0.3 ~18.98 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.1 ~0.2 ~18.98 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-12.0 ~0.3 ~17.84 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-12.0 ~0.2 ~17.84 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.77 ~0.3 ~16.51 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.77 ~0.2 ~16.51 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.4 ~0.3 ~15.01 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.4 ~0.2 ~15.01 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-16.86 ~0.3 ~13.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-16.86 ~0.2 ~13.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-18.14 ~0.3 ~11.54 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-18.14 ~0.2 ~11.54 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-19.23 ~0.3 ~9.61 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-19.23 ~0.2 ~9.61 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-20.12 ~0.3 ~7.58 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-20.12 ~0.2 ~7.58 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-20.79 ~0.3 ~5.48 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-20.79 ~0.2 ~5.48 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-21.24 ~0.3 ~3.31 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-21.24 ~0.2 ~3.31 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-21.47 ~0.3 ~1.11 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-21.47 ~0.2 ~1.11 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-21.47 ~0.3 ~-1.11 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-21.47 ~0.2 ~-1.11 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-21.24 ~0.3 ~-3.31 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-21.24 ~0.2 ~-3.31 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-20.79 ~0.3 ~-5.48 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-20.79 ~0.2 ~-5.48 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-20.12 ~0.3 ~-7.58 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-20.12 ~0.2 ~-7.58 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-19.23 ~0.3 ~-9.61 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-19.23 ~0.2 ~-9.61 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-18.14 ~0.3 ~-11.54 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-18.14 ~0.2 ~-11.54 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-16.86 ~0.3 ~-13.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-16.86 ~0.2 ~-13.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.4 ~0.3 ~-15.01 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.4 ~0.2 ~-15.01 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.77 ~0.3 ~-16.51 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.77 ~0.2 ~-16.51 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-12.0 ~0.3 ~-17.84 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-12.0 ~0.2 ~-17.84 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.1 ~0.3 ~-18.98 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.1 ~0.2 ~-18.98 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.1 ~0.3 ~-19.92 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.1 ~0.2 ~-19.92 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.01 ~0.3 ~-20.64 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.01 ~0.2 ~-20.64 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.85 ~0.3 ~-21.15 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.85 ~0.2 ~-21.15 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.66 ~0.3 ~-21.44 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.66 ~0.2 ~-21.44 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~0.55 ~0.3 ~-21.49 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~0.55 ~0.2 ~-21.49 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~2.76 ~0.3 ~-21.32 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~2.76 ~0.2 ~-21.32 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~4.94 ~0.3 ~-20.93 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~4.94 ~0.2 ~-20.93 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.06 ~0.3 ~-20.31 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.06 ~0.2 ~-20.31 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.11 ~0.3 ~-19.47 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.11 ~0.2 ~-19.47 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~11.07 ~0.3 ~-18.43 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.07 ~0.2 ~-18.43 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~12.9 ~0.3 ~-17.2 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~12.9 ~0.2 ~-17.2 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~14.6 ~0.3 ~-15.78 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~14.6 ~0.2 ~-15.78 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~16.15 ~0.3 ~-14.19 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~16.15 ~0.2 ~-14.19 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~17.52 ~0.3 ~-12.46 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~17.52 ~0.2 ~-12.46 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~18.71 ~0.3 ~-10.59 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~18.71 ~0.2 ~-10.59 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~19.7 ~0.3 ~-8.61 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~19.7 ~0.2 ~-8.61 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~20.48 ~0.3 ~-6.54 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~20.48 ~0.2 ~-6.54 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~21.05 ~0.3 ~-4.4 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~21.05 ~0.2 ~-4.4 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~21.39 ~0.3 ~-2.21 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~21.39 ~0.2 ~-2.21 0.3 0.2 0.3 0.05 1 force
