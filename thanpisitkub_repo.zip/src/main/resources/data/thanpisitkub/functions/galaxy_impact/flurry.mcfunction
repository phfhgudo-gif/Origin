particle minecraft:sweep_attack ^ ^1 ^2 1.5 1 1.5 0 2 force
particle minecraft:dust 1 0.15 0 3 ^ ^1 ^3 2 1.5 2 0 14 force
particle minecraft:dust 0.3 0 0 3 ^ ^1 ^3 2 1.5 2 0 6 force
particle minecraft:crit ^ ^1 ^3 2 2 2 0.5 10 force
particle minecraft:enchanted_hit ^ ^1 ^3 2 1.5 2 0.4 8 force
scoreboard players operation #m thp_tmp = @s thp_gi
scoreboard players operation #m thp_tmp %= #5 thp_const
execute if score #m thp_tmp matches 0 run playsound minecraft:entity.player.attack.sweep master @a ~ ~ ~ 3 0.7
execute if score #m thp_tmp matches 0 run playsound minecraft:entity.player.attack.strong master @a ~ ~ ~ 3 0.6
execute if score #m thp_tmp matches 0 run damage @e[tag=!thp_caster,distance=..8] 3 minecraft:player_attack by @s
