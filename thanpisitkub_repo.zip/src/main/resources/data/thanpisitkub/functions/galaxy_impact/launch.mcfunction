effect clear @s minecraft:slowness
effect clear @s minecraft:jump_boost
effect give @s minecraft:levitation 2 8 true
effect give @s minecraft:slow_falling 12 0 true
particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 0 1 force
particle minecraft:flash ~ ~1 ~ 0 0 0 0 1 force
particle minecraft:dust 1 0.2 0 4 ~ ~0.3 ~ 2.5 0.2 2.5 0 80 force
particle minecraft:cloud ~ ~ ~ 1.5 0.1 1.5 0.3 40 force
playsound minecraft:entity.generic.explode master @a ~ ~ ~ 4 0.8
