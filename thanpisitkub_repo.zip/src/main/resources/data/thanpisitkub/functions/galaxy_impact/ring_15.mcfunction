particle minecraft:dust 1 0.15 0 3 ~24.5 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~24.5 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~24.4 ~0.3 ~2.23 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~24.4 ~0.2 ~2.23 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~24.09 ~0.3 ~4.44 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~24.09 ~0.2 ~4.44 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~23.59 ~0.3 ~6.61 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~23.59 ~0.2 ~6.61 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~22.89 ~0.3 ~8.73 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~22.89 ~0.2 ~8.73 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~22.0 ~0.3 ~10.77 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~22.0 ~0.2 ~10.77 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~20.93 ~0.3 ~12.73 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~20.93 ~0.2 ~12.73 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~19.69 ~0.3 ~14.58 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~19.69 ~0.2 ~14.58 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~18.28 ~0.3 ~16.31 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~18.28 ~0.2 ~16.31 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~16.72 ~0.3 ~17.91 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~16.72 ~0.2 ~17.91 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~15.03 ~0.3 ~19.35 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~15.03 ~0.2 ~19.35 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.2 ~0.3 ~20.64 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.2 ~0.2 ~20.64 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~11.27 ~0.3 ~21.75 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.27 ~0.2 ~21.75 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.25 ~0.3 ~22.69 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.25 ~0.2 ~22.69 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.15 ~0.3 ~23.43 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.15 ~0.2 ~23.43 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~4.98 ~0.3 ~23.99 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~4.98 ~0.2 ~23.99 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~2.78 ~0.3 ~24.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~2.78 ~0.2 ~24.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~0.56 ~0.3 ~24.49 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~0.56 ~0.2 ~24.49 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.67 ~0.3 ~24.44 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.67 ~0.2 ~24.44 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.89 ~0.3 ~24.19 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.89 ~0.2 ~24.19 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.07 ~0.3 ~23.74 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.07 ~0.2 ~23.74 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.2 ~0.3 ~23.09 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.2 ~0.2 ~23.09 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.27 ~0.3 ~22.24 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.27 ~0.2 ~22.24 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-12.25 ~0.3 ~21.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-12.25 ~0.2 ~21.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-14.13 ~0.3 ~20.02 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-14.13 ~0.2 ~20.02 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.89 ~0.3 ~18.65 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.89 ~0.2 ~18.65 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.52 ~0.3 ~17.13 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.52 ~0.2 ~17.13 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-19.0 ~0.3 ~15.46 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-19.0 ~0.2 ~15.46 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-20.33 ~0.3 ~13.67 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-20.33 ~0.2 ~13.67 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-21.49 ~0.3 ~11.76 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-21.49 ~0.2 ~11.76 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-22.47 ~0.3 ~9.76 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-22.47 ~0.2 ~9.76 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-23.27 ~0.3 ~7.68 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-23.27 ~0.2 ~7.68 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-23.87 ~0.3 ~5.53 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-23.87 ~0.2 ~5.53 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-24.27 ~0.3 ~3.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-24.27 ~0.2 ~3.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-24.47 ~0.3 ~1.12 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-24.47 ~0.2 ~1.12 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-24.47 ~0.3 ~-1.12 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-24.47 ~0.2 ~-1.12 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-24.27 ~0.3 ~-3.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-24.27 ~0.2 ~-3.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-23.87 ~0.3 ~-5.53 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-23.87 ~0.2 ~-5.53 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-23.27 ~0.3 ~-7.68 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-23.27 ~0.2 ~-7.68 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-22.47 ~0.3 ~-9.76 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-22.47 ~0.2 ~-9.76 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-21.49 ~0.3 ~-11.76 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-21.49 ~0.2 ~-11.76 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-20.33 ~0.3 ~-13.67 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-20.33 ~0.2 ~-13.67 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-19.0 ~0.3 ~-15.46 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-19.0 ~0.2 ~-15.46 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.52 ~0.3 ~-17.13 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.52 ~0.2 ~-17.13 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.89 ~0.3 ~-18.65 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.89 ~0.2 ~-18.65 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-14.13 ~0.3 ~-20.02 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-14.13 ~0.2 ~-20.02 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-12.25 ~0.3 ~-21.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-12.25 ~0.2 ~-21.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.27 ~0.3 ~-22.24 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.27 ~0.2 ~-22.24 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.2 ~0.3 ~-23.09 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.2 ~0.2 ~-23.09 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.07 ~0.3 ~-23.74 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.07 ~0.2 ~-23.74 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.89 ~0.3 ~-24.19 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.89 ~0.2 ~-24.19 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.67 ~0.3 ~-24.44 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.67 ~0.2 ~-24.44 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~0.56 ~0.3 ~-24.49 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~0.56 ~0.2 ~-24.49 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~2.78 ~0.3 ~-24.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~2.78 ~0.2 ~-24.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~4.98 ~0.3 ~-23.99 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~4.98 ~0.2 ~-23.99 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.15 ~0.3 ~-23.43 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.15 ~0.2 ~-23.43 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.25 ~0.3 ~-22.69 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.25 ~0.2 ~-22.69 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~11.27 ~0.3 ~-21.75 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.27 ~0.2 ~-21.75 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.2 ~0.3 ~-20.64 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.2 ~0.2 ~-20.64 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~15.03 ~0.3 ~-19.35 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~15.03 ~0.2 ~-19.35 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~16.72 ~0.3 ~-17.91 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~16.72 ~0.2 ~-17.91 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~18.28 ~0.3 ~-16.31 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~18.28 ~0.2 ~-16.31 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~19.69 ~0.3 ~-14.58 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~19.69 ~0.2 ~-14.58 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~20.93 ~0.3 ~-12.73 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~20.93 ~0.2 ~-12.73 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~22.0 ~0.3 ~-10.77 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~22.0 ~0.2 ~-10.77 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~22.89 ~0.3 ~-8.73 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~22.89 ~0.2 ~-8.73 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~23.59 ~0.3 ~-6.61 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~23.59 ~0.2 ~-6.61 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~24.09 ~0.3 ~-4.44 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~24.09 ~0.2 ~-4.44 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~24.4 ~0.3 ~-2.23 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~24.4 ~0.2 ~-2.23 0.3 0.2 0.3 0.05 1 force
