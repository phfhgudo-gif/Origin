execute rotated ~ 0 run particle thanpisitkub:garp_ult1_8_2 ^0.0 ^7.37 ^1.0 0 0 0 0 1 force
