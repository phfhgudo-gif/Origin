particle minecraft:dust 1 0.15 0 3 ~2.0 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~2.0 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.62 ~0.3 ~1.18 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.62 ~0.2 ~1.18 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~0.62 ~0.3 ~1.9 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~0.62 ~0.2 ~1.9 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-0.62 ~0.3 ~1.9 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-0.62 ~0.2 ~1.9 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.62 ~0.3 ~1.18 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.62 ~0.2 ~1.18 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.0 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.0 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.62 ~0.3 ~-1.18 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.62 ~0.2 ~-1.18 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-0.62 ~0.3 ~-1.9 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-0.62 ~0.2 ~-1.9 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~0.62 ~0.3 ~-1.9 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~0.62 ~0.2 ~-1.9 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.62 ~0.3 ~-1.18 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.62 ~0.2 ~-1.18 0.3 0.2 0.3 0.05 1 force
