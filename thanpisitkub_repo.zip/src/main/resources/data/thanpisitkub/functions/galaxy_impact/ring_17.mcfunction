particle minecraft:dust 1 0.15 0 3 ~27.5 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~27.5 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~27.41 ~0.3 ~2.21 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~27.41 ~0.2 ~2.21 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~27.14 ~0.3 ~4.41 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~27.14 ~0.2 ~4.41 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~26.7 ~0.3 ~6.58 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~26.7 ~0.2 ~6.58 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~26.08 ~0.3 ~8.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~26.08 ~0.2 ~8.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~25.3 ~0.3 ~10.78 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~25.3 ~0.2 ~10.78 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~24.35 ~0.3 ~12.78 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~24.35 ~0.2 ~12.78 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~23.24 ~0.3 ~14.7 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~23.24 ~0.2 ~14.7 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~21.98 ~0.3 ~16.52 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~21.98 ~0.2 ~16.52 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~20.58 ~0.3 ~18.24 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~20.58 ~0.2 ~18.24 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~19.05 ~0.3 ~19.83 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~19.05 ~0.2 ~19.83 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~17.39 ~0.3 ~21.3 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~17.39 ~0.2 ~21.3 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~15.62 ~0.3 ~22.63 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~15.62 ~0.2 ~22.63 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.75 ~0.3 ~23.82 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.75 ~0.2 ~23.82 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~11.79 ~0.3 ~24.84 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.79 ~0.2 ~24.84 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.75 ~0.3 ~25.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.75 ~0.2 ~25.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.65 ~0.3 ~26.41 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.65 ~0.2 ~26.41 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~5.5 ~0.3 ~26.94 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~5.5 ~0.2 ~26.94 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.31 ~0.3 ~27.3 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.31 ~0.2 ~27.3 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.11 ~0.3 ~27.48 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.11 ~0.2 ~27.48 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.11 ~0.3 ~27.48 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.11 ~0.2 ~27.48 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.31 ~0.3 ~27.3 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.31 ~0.2 ~27.3 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-5.5 ~0.3 ~26.94 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-5.5 ~0.2 ~26.94 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-7.65 ~0.3 ~26.41 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-7.65 ~0.2 ~26.41 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-9.75 ~0.3 ~25.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-9.75 ~0.2 ~25.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-11.79 ~0.3 ~24.84 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-11.79 ~0.2 ~24.84 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.75 ~0.3 ~23.82 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.75 ~0.2 ~23.82 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.62 ~0.3 ~22.63 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.62 ~0.2 ~22.63 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.39 ~0.3 ~21.3 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.39 ~0.2 ~21.3 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-19.05 ~0.3 ~19.83 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-19.05 ~0.2 ~19.83 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-20.58 ~0.3 ~18.24 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-20.58 ~0.2 ~18.24 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-21.98 ~0.3 ~16.52 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-21.98 ~0.2 ~16.52 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-23.24 ~0.3 ~14.7 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-23.24 ~0.2 ~14.7 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-24.35 ~0.3 ~12.78 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-24.35 ~0.2 ~12.78 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-25.3 ~0.3 ~10.78 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-25.3 ~0.2 ~10.78 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-26.08 ~0.3 ~8.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-26.08 ~0.2 ~8.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-26.7 ~0.3 ~6.58 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-26.7 ~0.2 ~6.58 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-27.14 ~0.3 ~4.41 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-27.14 ~0.2 ~4.41 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-27.41 ~0.3 ~2.21 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-27.41 ~0.2 ~2.21 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-27.5 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-27.5 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-27.41 ~0.3 ~-2.21 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-27.41 ~0.2 ~-2.21 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-27.14 ~0.3 ~-4.41 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-27.14 ~0.2 ~-4.41 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-26.7 ~0.3 ~-6.58 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-26.7 ~0.2 ~-6.58 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-26.08 ~0.3 ~-8.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-26.08 ~0.2 ~-8.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-25.3 ~0.3 ~-10.78 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-25.3 ~0.2 ~-10.78 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-24.35 ~0.3 ~-12.78 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-24.35 ~0.2 ~-12.78 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-23.24 ~0.3 ~-14.7 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-23.24 ~0.2 ~-14.7 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-21.98 ~0.3 ~-16.52 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-21.98 ~0.2 ~-16.52 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-20.58 ~0.3 ~-18.24 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-20.58 ~0.2 ~-18.24 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-19.05 ~0.3 ~-19.83 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-19.05 ~0.2 ~-19.83 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.39 ~0.3 ~-21.3 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.39 ~0.2 ~-21.3 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.62 ~0.3 ~-22.63 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.62 ~0.2 ~-22.63 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.75 ~0.3 ~-23.82 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.75 ~0.2 ~-23.82 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-11.79 ~0.3 ~-24.84 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-11.79 ~0.2 ~-24.84 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-9.75 ~0.3 ~-25.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-9.75 ~0.2 ~-25.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-7.65 ~0.3 ~-26.41 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-7.65 ~0.2 ~-26.41 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-5.5 ~0.3 ~-26.94 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-5.5 ~0.2 ~-26.94 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.31 ~0.3 ~-27.3 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.31 ~0.2 ~-27.3 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.11 ~0.3 ~-27.48 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.11 ~0.2 ~-27.48 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.11 ~0.3 ~-27.48 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.11 ~0.2 ~-27.48 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.31 ~0.3 ~-27.3 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.31 ~0.2 ~-27.3 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~5.5 ~0.3 ~-26.94 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~5.5 ~0.2 ~-26.94 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.65 ~0.3 ~-26.41 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.65 ~0.2 ~-26.41 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.75 ~0.3 ~-25.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.75 ~0.2 ~-25.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~11.79 ~0.3 ~-24.84 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.79 ~0.2 ~-24.84 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.75 ~0.3 ~-23.82 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.75 ~0.2 ~-23.82 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~15.62 ~0.3 ~-22.63 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~15.62 ~0.2 ~-22.63 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~17.39 ~0.3 ~-21.3 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~17.39 ~0.2 ~-21.3 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~19.05 ~0.3 ~-19.83 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~19.05 ~0.2 ~-19.83 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~20.58 ~0.3 ~-18.24 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~20.58 ~0.2 ~-18.24 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~21.98 ~0.3 ~-16.52 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~21.98 ~0.2 ~-16.52 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~23.24 ~0.3 ~-14.7 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~23.24 ~0.2 ~-14.7 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~24.35 ~0.3 ~-12.78 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~24.35 ~0.2 ~-12.78 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~25.3 ~0.3 ~-10.78 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~25.3 ~0.2 ~-10.78 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~26.08 ~0.3 ~-8.71 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~26.08 ~0.2 ~-8.71 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~26.7 ~0.3 ~-6.58 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~26.7 ~0.2 ~-6.58 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~27.14 ~0.3 ~-4.41 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~27.14 ~0.2 ~-4.41 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~27.41 ~0.3 ~-2.21 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~27.41 ~0.2 ~-2.21 0.3 0.2 0.3 0.05 1 force
