particle minecraft:dust 1 0.15 0 3 ~9.5 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.5 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.24 ~0.3 ~2.19 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.24 ~0.2 ~2.19 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~8.49 ~0.3 ~4.26 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~8.49 ~0.2 ~4.26 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.28 ~0.3 ~6.11 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.28 ~0.2 ~6.11 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~5.67 ~0.3 ~7.62 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~5.67 ~0.2 ~7.62 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.76 ~0.3 ~8.72 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.76 ~0.2 ~8.72 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.65 ~0.3 ~9.36 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.65 ~0.2 ~9.36 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-0.55 ~0.3 ~9.48 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-0.55 ~0.2 ~9.48 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.72 ~0.3 ~9.1 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.72 ~0.2 ~9.1 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.75 ~0.3 ~8.23 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.75 ~0.2 ~8.23 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.52 ~0.3 ~6.91 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.52 ~0.2 ~6.91 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-7.94 ~0.3 ~5.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-7.94 ~0.2 ~5.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.93 ~0.3 ~3.25 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.93 ~0.2 ~3.25 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-9.44 ~0.3 ~1.1 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-9.44 ~0.2 ~1.1 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-9.44 ~0.3 ~-1.1 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-9.44 ~0.2 ~-1.1 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.93 ~0.3 ~-3.25 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.93 ~0.2 ~-3.25 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-7.94 ~0.3 ~-5.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-7.94 ~0.2 ~-5.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.52 ~0.3 ~-6.91 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.52 ~0.2 ~-6.91 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.75 ~0.3 ~-8.23 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.75 ~0.2 ~-8.23 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.72 ~0.3 ~-9.1 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.72 ~0.2 ~-9.1 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-0.55 ~0.3 ~-9.48 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-0.55 ~0.2 ~-9.48 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.65 ~0.3 ~-9.36 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.65 ~0.2 ~-9.36 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.76 ~0.3 ~-8.72 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.76 ~0.2 ~-8.72 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~5.67 ~0.3 ~-7.62 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~5.67 ~0.2 ~-7.62 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.28 ~0.3 ~-6.11 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.28 ~0.2 ~-6.11 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~8.49 ~0.3 ~-4.26 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~8.49 ~0.2 ~-4.26 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.24 ~0.3 ~-2.19 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.24 ~0.2 ~-2.19 0.3 0.2 0.3 0.05 1 force
