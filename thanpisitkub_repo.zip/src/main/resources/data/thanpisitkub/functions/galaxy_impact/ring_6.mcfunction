particle minecraft:dust 1 0.15 0 3 ~11.0 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.0 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~10.77 ~0.3 ~2.21 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~10.77 ~0.2 ~2.21 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~10.11 ~0.3 ~4.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~10.11 ~0.2 ~4.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.03 ~0.3 ~6.28 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.03 ~0.2 ~6.28 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.58 ~0.3 ~7.97 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.58 ~0.2 ~7.97 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~5.82 ~0.3 ~9.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~5.82 ~0.2 ~9.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.82 ~0.3 ~10.32 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.82 ~0.2 ~10.32 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.67 ~0.3 ~10.87 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.67 ~0.2 ~10.87 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-0.56 ~0.3 ~10.99 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-0.56 ~0.2 ~10.99 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.76 ~0.3 ~10.65 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.76 ~0.2 ~10.65 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.84 ~0.3 ~9.88 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.84 ~0.2 ~9.88 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.73 ~0.3 ~8.7 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.73 ~0.2 ~8.7 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.35 ~0.3 ~7.17 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.35 ~0.2 ~7.17 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-9.62 ~0.3 ~5.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-9.62 ~0.2 ~5.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.5 ~0.3 ~3.29 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.5 ~0.2 ~3.29 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.94 ~0.3 ~1.11 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.94 ~0.2 ~1.11 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.94 ~0.3 ~-1.11 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.94 ~0.2 ~-1.11 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.5 ~0.3 ~-3.29 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.5 ~0.2 ~-3.29 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-9.62 ~0.3 ~-5.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-9.62 ~0.2 ~-5.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.35 ~0.3 ~-7.17 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.35 ~0.2 ~-7.17 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-6.73 ~0.3 ~-8.7 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-6.73 ~0.2 ~-8.7 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.84 ~0.3 ~-9.88 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.84 ~0.2 ~-9.88 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.76 ~0.3 ~-10.65 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.76 ~0.2 ~-10.65 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-0.56 ~0.3 ~-10.99 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-0.56 ~0.2 ~-10.99 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.67 ~0.3 ~-10.87 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.67 ~0.2 ~-10.87 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.82 ~0.3 ~-10.32 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.82 ~0.2 ~-10.32 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~5.82 ~0.3 ~-9.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~5.82 ~0.2 ~-9.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.58 ~0.3 ~-7.97 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.58 ~0.2 ~-7.97 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.03 ~0.3 ~-6.28 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.03 ~0.2 ~-6.28 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~10.11 ~0.3 ~-4.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~10.11 ~0.2 ~-4.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~10.77 ~0.3 ~-2.21 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~10.77 ~0.2 ~-2.21 0.3 0.2 0.3 0.05 1 force
