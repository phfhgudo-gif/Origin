particle minecraft:dust 1 0.15 0 3 ~30.5 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~30.5 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~30.42 ~0.3 ~2.2 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~30.42 ~0.2 ~2.2 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~30.18 ~0.3 ~4.39 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~30.18 ~0.2 ~4.39 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~29.79 ~0.3 ~6.56 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~29.79 ~0.2 ~6.56 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~29.24 ~0.3 ~8.69 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~29.24 ~0.2 ~8.69 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~28.53 ~0.3 ~10.78 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~28.53 ~0.2 ~10.78 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~27.68 ~0.3 ~12.81 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~27.68 ~0.2 ~12.81 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~26.68 ~0.3 ~14.77 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~26.68 ~0.2 ~14.77 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~25.55 ~0.3 ~16.66 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~25.55 ~0.2 ~16.66 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~24.28 ~0.3 ~18.46 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~24.28 ~0.2 ~18.46 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~22.89 ~0.3 ~20.16 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~22.89 ~0.2 ~20.16 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~21.37 ~0.3 ~21.76 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~21.37 ~0.2 ~21.76 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~19.75 ~0.3 ~23.25 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~19.75 ~0.2 ~23.25 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~18.02 ~0.3 ~24.61 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~18.02 ~0.2 ~24.61 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~16.19 ~0.3 ~25.85 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~16.19 ~0.2 ~25.85 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~14.29 ~0.3 ~26.95 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~14.29 ~0.2 ~26.95 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~12.3 ~0.3 ~27.91 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~12.3 ~0.2 ~27.91 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~10.26 ~0.3 ~28.72 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~10.26 ~0.2 ~28.72 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~8.16 ~0.3 ~29.39 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~8.16 ~0.2 ~29.39 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~6.02 ~0.3 ~29.9 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~6.02 ~0.2 ~29.9 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.84 ~0.3 ~30.26 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.84 ~0.2 ~30.26 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.65 ~0.3 ~30.46 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.65 ~0.2 ~30.46 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-0.55 ~0.3 ~30.5 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-0.55 ~0.2 ~30.5 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.75 ~0.3 ~30.38 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.75 ~0.2 ~30.38 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.93 ~0.3 ~30.1 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.93 ~0.2 ~30.1 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-7.09 ~0.3 ~29.66 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-7.09 ~0.2 ~29.66 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-9.22 ~0.3 ~29.07 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-9.22 ~0.2 ~29.07 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-11.29 ~0.3 ~28.33 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-11.29 ~0.2 ~28.33 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.3 ~0.3 ~27.45 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.3 ~0.2 ~27.45 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.25 ~0.3 ~26.41 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.25 ~0.2 ~26.41 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.12 ~0.3 ~25.24 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.12 ~0.2 ~25.24 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-18.89 ~0.3 ~23.94 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-18.89 ~0.2 ~23.94 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-20.57 ~0.3 ~22.52 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-20.57 ~0.2 ~22.52 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-22.14 ~0.3 ~20.97 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-22.14 ~0.2 ~20.97 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-23.6 ~0.3 ~19.32 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-23.6 ~0.2 ~19.32 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-24.93 ~0.3 ~17.57 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-24.93 ~0.2 ~17.57 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-26.13 ~0.3 ~15.72 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-26.13 ~0.2 ~15.72 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-27.2 ~0.3 ~13.8 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-27.2 ~0.2 ~13.8 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-28.13 ~0.3 ~11.8 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-28.13 ~0.2 ~11.8 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-28.9 ~0.3 ~9.74 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-28.9 ~0.2 ~9.74 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-29.53 ~0.3 ~7.63 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-29.53 ~0.2 ~7.63 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-30.0 ~0.3 ~5.48 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-30.0 ~0.2 ~5.48 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-30.32 ~0.3 ~3.3 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-30.32 ~0.2 ~3.3 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-30.48 ~0.3 ~1.1 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-30.48 ~0.2 ~1.1 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-30.48 ~0.3 ~-1.1 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-30.48 ~0.2 ~-1.1 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-30.32 ~0.3 ~-3.3 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-30.32 ~0.2 ~-3.3 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-30.0 ~0.3 ~-5.48 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-30.0 ~0.2 ~-5.48 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-29.53 ~0.3 ~-7.63 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-29.53 ~0.2 ~-7.63 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-28.9 ~0.3 ~-9.74 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-28.9 ~0.2 ~-9.74 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-28.13 ~0.3 ~-11.8 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-28.13 ~0.2 ~-11.8 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-27.2 ~0.3 ~-13.8 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-27.2 ~0.2 ~-13.8 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-26.13 ~0.3 ~-15.72 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-26.13 ~0.2 ~-15.72 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-24.93 ~0.3 ~-17.57 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-24.93 ~0.2 ~-17.57 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-23.6 ~0.3 ~-19.32 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-23.6 ~0.2 ~-19.32 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-22.14 ~0.3 ~-20.97 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-22.14 ~0.2 ~-20.97 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-20.57 ~0.3 ~-22.52 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-20.57 ~0.2 ~-22.52 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-18.89 ~0.3 ~-23.94 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-18.89 ~0.2 ~-23.94 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.12 ~0.3 ~-25.24 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.12 ~0.2 ~-25.24 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.25 ~0.3 ~-26.41 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.25 ~0.2 ~-26.41 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.3 ~0.3 ~-27.45 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.3 ~0.2 ~-27.45 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-11.29 ~0.3 ~-28.33 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-11.29 ~0.2 ~-28.33 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-9.22 ~0.3 ~-29.07 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-9.22 ~0.2 ~-29.07 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-7.09 ~0.3 ~-29.66 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-7.09 ~0.2 ~-29.66 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.93 ~0.3 ~-30.1 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.93 ~0.2 ~-30.1 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.75 ~0.3 ~-30.38 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.75 ~0.2 ~-30.38 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-0.55 ~0.3 ~-30.5 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-0.55 ~0.2 ~-30.5 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.65 ~0.3 ~-30.46 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.65 ~0.2 ~-30.46 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.84 ~0.3 ~-30.26 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.84 ~0.2 ~-30.26 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~6.02 ~0.3 ~-29.9 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~6.02 ~0.2 ~-29.9 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~8.16 ~0.3 ~-29.39 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~8.16 ~0.2 ~-29.39 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~10.26 ~0.3 ~-28.72 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~10.26 ~0.2 ~-28.72 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~12.3 ~0.3 ~-27.91 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~12.3 ~0.2 ~-27.91 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~14.29 ~0.3 ~-26.95 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~14.29 ~0.2 ~-26.95 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~16.19 ~0.3 ~-25.85 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~16.19 ~0.2 ~-25.85 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~18.02 ~0.3 ~-24.61 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~18.02 ~0.2 ~-24.61 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~19.75 ~0.3 ~-23.25 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~19.75 ~0.2 ~-23.25 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~21.37 ~0.3 ~-21.76 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~21.37 ~0.2 ~-21.76 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~22.89 ~0.3 ~-20.16 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~22.89 ~0.2 ~-20.16 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~24.28 ~0.3 ~-18.46 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~24.28 ~0.2 ~-18.46 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~25.55 ~0.3 ~-16.66 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~25.55 ~0.2 ~-16.66 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~26.68 ~0.3 ~-14.77 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~26.68 ~0.2 ~-14.77 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~27.68 ~0.3 ~-12.81 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~27.68 ~0.2 ~-12.81 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~28.53 ~0.3 ~-10.78 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~28.53 ~0.2 ~-10.78 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~29.24 ~0.3 ~-8.69 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~29.24 ~0.2 ~-8.69 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~29.79 ~0.3 ~-6.56 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~29.79 ~0.2 ~-6.56 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~30.18 ~0.3 ~-4.39 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~30.18 ~0.2 ~-4.39 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~30.42 ~0.3 ~-2.2 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~30.42 ~0.2 ~-2.2 0.3 0.2 0.3 0.05 1 force
