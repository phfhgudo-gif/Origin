tag @s add thp_caster
scoreboard players set @s thp_gi 1
# main sound (swap for: thanpisitkub:galaxy , thanpisitkub:impact , thanpisitkub:galaxy_impact_theme if you prefer)
playsound thanpisitkub:garp_ult1 master @a ~ ~ ~ 6 1
effect give @s minecraft:resistance 28 4 true
effect give @s minecraft:fire_resistance 28 0 true
effect give @s minecraft:slowness 5 6 true
effect give @s minecraft:jump_boost 5 128 true
