playsound thanpisitkub:garp_ult1 master @a ~ ~ ~ 6 1
# other sounds you can use instead: thanpisitkub:galaxy  thanpisitkub:impact  thanpisitkub:galaxy_impact_theme
effect give @s minecraft:resistance 26 4 true
effect give @s minecraft:slowness 24 6 true
effect give @s minecraft:jump_boost 24 128 true
scoreboard players set @s thp_gi 1
tag @s add thp_caster
thanpisitkub anim galaxy_impact
