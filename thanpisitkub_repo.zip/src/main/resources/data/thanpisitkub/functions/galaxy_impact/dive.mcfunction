effect clear @s minecraft:slow_falling
particle minecraft:flame ~ ~1 ~ 0.6 1 0.6 0.2 40 force
particle minecraft:dust 1 0.1 0 4 ~ ~1 ~ 1 1 1 0 60 force
playsound minecraft:entity.generic.explode master @a ~ ~ ~ 4 0.7
