particle minecraft:dust 1 0.15 0 3 ~29.0 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~29.0 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~28.91 ~0.3 ~2.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~28.91 ~0.2 ~2.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~28.66 ~0.3 ~4.43 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~28.66 ~0.2 ~4.43 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~28.24 ~0.3 ~6.61 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~28.24 ~0.2 ~6.61 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~27.65 ~0.3 ~8.75 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~27.65 ~0.2 ~8.75 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~26.9 ~0.3 ~10.84 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~26.9 ~0.2 ~10.84 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~25.99 ~0.3 ~12.87 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~25.99 ~0.2 ~12.87 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~24.93 ~0.3 ~14.82 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~24.93 ~0.2 ~14.82 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~23.72 ~0.3 ~16.68 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~23.72 ~0.2 ~16.68 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~22.37 ~0.3 ~18.45 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~22.37 ~0.2 ~18.45 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~20.9 ~0.3 ~20.11 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~20.9 ~0.2 ~20.11 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~19.29 ~0.3 ~21.65 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~19.29 ~0.2 ~21.65 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~17.58 ~0.3 ~23.06 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~17.58 ~0.2 ~23.06 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~15.76 ~0.3 ~24.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~15.76 ~0.2 ~24.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.85 ~0.3 ~25.48 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.85 ~0.2 ~25.48 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~11.86 ~0.3 ~26.46 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.86 ~0.2 ~26.46 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.8 ~0.3 ~27.29 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.8 ~0.2 ~27.29 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.68 ~0.3 ~27.96 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.68 ~0.2 ~27.96 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~5.52 ~0.3 ~28.47 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~5.52 ~0.2 ~28.47 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.33 ~0.3 ~28.81 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.33 ~0.2 ~28.81 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.11 ~0.3 ~28.98 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.11 ~0.2 ~28.98 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.11 ~0.3 ~28.98 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.11 ~0.2 ~28.98 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.33 ~0.3 ~28.81 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.33 ~0.2 ~28.81 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-5.52 ~0.3 ~28.47 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-5.52 ~0.2 ~28.47 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-7.68 ~0.3 ~27.96 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-7.68 ~0.2 ~27.96 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-9.8 ~0.3 ~27.29 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-9.8 ~0.2 ~27.29 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-11.86 ~0.3 ~26.46 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-11.86 ~0.2 ~26.46 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.85 ~0.3 ~25.48 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.85 ~0.2 ~25.48 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.76 ~0.3 ~24.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.76 ~0.2 ~24.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.58 ~0.3 ~23.06 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.58 ~0.2 ~23.06 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-19.29 ~0.3 ~21.65 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-19.29 ~0.2 ~21.65 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-20.9 ~0.3 ~20.11 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-20.9 ~0.2 ~20.11 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-22.37 ~0.3 ~18.45 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-22.37 ~0.2 ~18.45 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-23.72 ~0.3 ~16.68 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-23.72 ~0.2 ~16.68 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-24.93 ~0.3 ~14.82 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-24.93 ~0.2 ~14.82 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-25.99 ~0.3 ~12.87 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-25.99 ~0.2 ~12.87 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-26.9 ~0.3 ~10.84 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-26.9 ~0.2 ~10.84 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-27.65 ~0.3 ~8.75 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-27.65 ~0.2 ~8.75 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-28.24 ~0.3 ~6.61 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-28.24 ~0.2 ~6.61 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-28.66 ~0.3 ~4.43 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-28.66 ~0.2 ~4.43 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-28.91 ~0.3 ~2.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-28.91 ~0.2 ~2.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-29.0 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-29.0 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-28.91 ~0.3 ~-2.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-28.91 ~0.2 ~-2.22 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-28.66 ~0.3 ~-4.43 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-28.66 ~0.2 ~-4.43 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-28.24 ~0.3 ~-6.61 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-28.24 ~0.2 ~-6.61 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-27.65 ~0.3 ~-8.75 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-27.65 ~0.2 ~-8.75 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-26.9 ~0.3 ~-10.84 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-26.9 ~0.2 ~-10.84 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-25.99 ~0.3 ~-12.87 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-25.99 ~0.2 ~-12.87 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-24.93 ~0.3 ~-14.82 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-24.93 ~0.2 ~-14.82 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-23.72 ~0.3 ~-16.68 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-23.72 ~0.2 ~-16.68 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-22.37 ~0.3 ~-18.45 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-22.37 ~0.2 ~-18.45 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-20.9 ~0.3 ~-20.11 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-20.9 ~0.2 ~-20.11 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-19.29 ~0.3 ~-21.65 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-19.29 ~0.2 ~-21.65 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-17.58 ~0.3 ~-23.06 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-17.58 ~0.2 ~-23.06 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-15.76 ~0.3 ~-24.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-15.76 ~0.2 ~-24.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.85 ~0.3 ~-25.48 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.85 ~0.2 ~-25.48 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-11.86 ~0.3 ~-26.46 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-11.86 ~0.2 ~-26.46 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-9.8 ~0.3 ~-27.29 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-9.8 ~0.2 ~-27.29 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-7.68 ~0.3 ~-27.96 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-7.68 ~0.2 ~-27.96 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-5.52 ~0.3 ~-28.47 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-5.52 ~0.2 ~-28.47 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.33 ~0.3 ~-28.81 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.33 ~0.2 ~-28.81 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.11 ~0.3 ~-28.98 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.11 ~0.2 ~-28.98 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.11 ~0.3 ~-28.98 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.11 ~0.2 ~-28.98 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.33 ~0.3 ~-28.81 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.33 ~0.2 ~-28.81 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~5.52 ~0.3 ~-28.47 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~5.52 ~0.2 ~-28.47 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.68 ~0.3 ~-27.96 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.68 ~0.2 ~-27.96 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.8 ~0.3 ~-27.29 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.8 ~0.2 ~-27.29 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~11.86 ~0.3 ~-26.46 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.86 ~0.2 ~-26.46 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.85 ~0.3 ~-25.48 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.85 ~0.2 ~-25.48 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~15.76 ~0.3 ~-24.34 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~15.76 ~0.2 ~-24.34 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~17.58 ~0.3 ~-23.06 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~17.58 ~0.2 ~-23.06 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~19.29 ~0.3 ~-21.65 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~19.29 ~0.2 ~-21.65 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~20.9 ~0.3 ~-20.11 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~20.9 ~0.2 ~-20.11 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~22.37 ~0.3 ~-18.45 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~22.37 ~0.2 ~-18.45 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~23.72 ~0.3 ~-16.68 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~23.72 ~0.2 ~-16.68 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~24.93 ~0.3 ~-14.82 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~24.93 ~0.2 ~-14.82 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~25.99 ~0.3 ~-12.87 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~25.99 ~0.2 ~-12.87 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~26.9 ~0.3 ~-10.84 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~26.9 ~0.2 ~-10.84 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~27.65 ~0.3 ~-8.75 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~27.65 ~0.2 ~-8.75 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~28.24 ~0.3 ~-6.61 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~28.24 ~0.2 ~-6.61 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~28.66 ~0.3 ~-4.43 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~28.66 ~0.2 ~-4.43 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~28.91 ~0.3 ~-2.22 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~28.91 ~0.2 ~-2.22 0.3 0.2 0.3 0.05 1 force
