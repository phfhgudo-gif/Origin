particle minecraft:dust 1 0.15 0 3 ~5.0 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~5.0 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~4.5 ~0.3 ~2.17 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~4.5 ~0.2 ~2.17 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.12 ~0.3 ~3.91 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.12 ~0.2 ~3.91 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.11 ~0.3 ~4.87 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.11 ~0.2 ~4.87 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.11 ~0.3 ~4.87 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.11 ~0.2 ~4.87 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.12 ~0.3 ~3.91 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.12 ~0.2 ~3.91 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.5 ~0.3 ~2.17 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.5 ~0.2 ~2.17 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-5.0 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-5.0 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.5 ~0.3 ~-2.17 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.5 ~0.2 ~-2.17 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-3.12 ~0.3 ~-3.91 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-3.12 ~0.2 ~-3.91 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-1.11 ~0.3 ~-4.87 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-1.11 ~0.2 ~-4.87 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.11 ~0.3 ~-4.87 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.11 ~0.2 ~-4.87 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.12 ~0.3 ~-3.91 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.12 ~0.2 ~-3.91 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~4.5 ~0.3 ~-2.17 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~4.5 ~0.2 ~-2.17 0.3 0.2 0.3 0.05 1 force
