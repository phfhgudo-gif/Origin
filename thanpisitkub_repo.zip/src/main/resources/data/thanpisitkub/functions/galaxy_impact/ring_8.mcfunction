particle minecraft:dust 1 0.15 0 3 ~14.0 ~0.3 ~0.0 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~14.0 ~0.2 ~0.0 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.82 ~0.3 ~2.25 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.82 ~0.2 ~2.25 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.28 ~0.3 ~4.43 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.28 ~0.2 ~4.43 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~12.4 ~0.3 ~6.51 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~12.4 ~0.2 ~6.51 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~11.19 ~0.3 ~8.41 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.19 ~0.2 ~8.41 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.7 ~0.3 ~10.1 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.7 ~0.2 ~10.1 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.95 ~0.3 ~11.52 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.95 ~0.2 ~11.52 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~6.0 ~0.3 ~12.65 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~6.0 ~0.2 ~12.65 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.9 ~0.3 ~13.45 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.9 ~0.2 ~13.45 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.69 ~0.3 ~13.9 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.69 ~0.2 ~13.9 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-0.56 ~0.3 ~13.99 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-0.56 ~0.2 ~13.99 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.8 ~0.3 ~13.72 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.8 ~0.2 ~13.72 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.96 ~0.3 ~13.09 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.96 ~0.2 ~13.09 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-7.0 ~0.3 ~12.12 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-7.0 ~0.2 ~12.12 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.85 ~0.3 ~10.84 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.85 ~0.2 ~10.84 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.48 ~0.3 ~9.28 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.48 ~0.2 ~9.28 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-11.83 ~0.3 ~7.48 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-11.83 ~0.2 ~7.48 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-12.88 ~0.3 ~5.49 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-12.88 ~0.2 ~5.49 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.59 ~0.3 ~3.35 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.59 ~0.2 ~3.35 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.95 ~0.3 ~1.13 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.95 ~0.2 ~1.13 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.95 ~0.3 ~-1.13 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.95 ~0.2 ~-1.13 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-13.59 ~0.3 ~-3.35 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-13.59 ~0.2 ~-3.35 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-12.88 ~0.3 ~-5.49 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-12.88 ~0.2 ~-5.49 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-11.83 ~0.3 ~-7.48 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-11.83 ~0.2 ~-7.48 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-10.48 ~0.3 ~-9.28 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-10.48 ~0.2 ~-9.28 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-8.85 ~0.3 ~-10.84 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-8.85 ~0.2 ~-10.84 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-7.0 ~0.3 ~-12.12 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-7.0 ~0.2 ~-12.12 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-4.96 ~0.3 ~-13.09 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-4.96 ~0.2 ~-13.09 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-2.8 ~0.3 ~-13.72 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-2.8 ~0.2 ~-13.72 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~-0.56 ~0.3 ~-13.99 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~-0.56 ~0.2 ~-13.99 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~1.69 ~0.3 ~-13.9 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~1.69 ~0.2 ~-13.9 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~3.9 ~0.3 ~-13.45 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~3.9 ~0.2 ~-13.45 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~6.0 ~0.3 ~-12.65 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~6.0 ~0.2 ~-12.65 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~7.95 ~0.3 ~-11.52 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~7.95 ~0.2 ~-11.52 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~9.7 ~0.3 ~-10.1 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~9.7 ~0.2 ~-10.1 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~11.19 ~0.3 ~-8.41 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~11.19 ~0.2 ~-8.41 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~12.4 ~0.3 ~-6.51 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~12.4 ~0.2 ~-6.51 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.28 ~0.3 ~-4.43 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.28 ~0.2 ~-4.43 0.3 0.2 0.3 0.05 1 force
particle minecraft:dust 1 0.15 0 3 ~13.82 ~0.3 ~-2.25 0.4 0.2 0.4 0 3 force
particle minecraft:flame ~13.82 ~0.2 ~-2.25 0.3 0.2 0.3 0.05 1 force
