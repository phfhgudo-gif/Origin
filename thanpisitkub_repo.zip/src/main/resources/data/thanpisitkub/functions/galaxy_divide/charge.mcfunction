particle minecraft:end_rod ~ ~1.2 ~ 2.2 2.2 2.2 0.05 6 force
particle minecraft:dust_color_transition 1 0.9 0 2 1 0.1 0 ~ ~1.2 ~ 1.8 1.8 1.8 0 10 force
particle minecraft:soul_fire_flame ~ ~0.2 ~ 1.2 0.1 1.2 0.05 4 force
particle minecraft:flame ~ ~1 ~ 1.5 1.5 1.5 0.1 4 force
particle minecraft:glow ~ ~1.2 ~ 2.5 2.5 2.5 0.1 5 force
execute if score @s thp_gd matches 30 run playsound minecraft:block.beacon.activate master @a ~ ~ ~ 3 0.5
