thanpisitkub anim stop
effect clear @s minecraft:slowness
effect clear @s minecraft:jump_boost
effect clear @s minecraft:resistance
tag @s remove thp_caster
scoreboard players reset @s thp_gd
