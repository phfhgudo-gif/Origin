kill @e[type=minecraft:marker,tag=thp_gd_mark,distance=..8]
tag @s remove thp_caster
scoreboard players reset @s thp_gd
