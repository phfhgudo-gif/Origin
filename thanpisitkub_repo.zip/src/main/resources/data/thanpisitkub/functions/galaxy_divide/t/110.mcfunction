execute rotated ~ 0 run particle thanpisitkub:garp_ult4_2 ^-0.5 ^1.3 ^0.8 0 0 0 0 1 force
