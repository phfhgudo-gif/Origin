execute rotated ~ 0 run particle thanpisitkub:garp_ult4_2 ^0 ^1.0 ^0.5 0 0 0 0 1 force
