# ground crack
particle minecraft:dust 0.05 0 0 3 ~ ~0.2 ~ 1.4 0.1 1.4 0 8 force
particle minecraft:lava ~ ~0.3 ~ 1.2 0.1 1.2 0 2 force
# wall of galaxy light
particle minecraft:end_rod ~ ~4 ~ 0.5 4 0.5 0.06 12 force
particle minecraft:dust_color_transition 1 0.9 0 3 1 0.1 0 ~ ~5 ~ 1 6 1 0 20 force
particle minecraft:soul_fire_flame ~ ~2 ~ 1 3 1 0.03 5 force
particle minecraft:glow ~ ~3 ~ 1 4 1 0.1 4 force
particle minecraft:explosion ~ ~1 ~ 1 0.5 1 0 1 force
damage @e[tag=!thp_caster,distance=..5] 12 minecraft:player_attack by @p[tag=thp_caster]
