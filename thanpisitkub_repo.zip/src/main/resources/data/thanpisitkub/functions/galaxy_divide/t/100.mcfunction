execute rotated ~ 0 run particle thanpisitkub:garp_ult1_3_3 ^0 ^1.0 ^0 0 0 0 0 1 force
