execute rotated ~ 0 run particle thanpisitkub:garp_galaxydivide2 ^0.0 ^1.0 ^-2.62 0 0 0 0 1 force
