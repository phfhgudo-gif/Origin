execute rotated ~ 0 run particle thanpisitkub:garp_galaxydivide1 ^-0.5 ^1.3 ^0.8 0 0 0 0 1 force
damage @e[tag=!thp_caster,distance=..6] 2 minecraft:player_attack by @s
