execute rotated ~ 0 run particle thanpisitkub:garp_rubi2_4 ^0 ^1.0 ^0 0 0 0 0 1 force
