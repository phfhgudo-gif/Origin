summon minecraft:marker ~ ~ ~ {Tags:["thp_gd_mark"]}
execute as @e[type=minecraft:marker,tag=thp_gd_mark,distance=..1,limit=1,sort=nearest] at @s rotated as @p[tag=thp_caster] run tp @s ~ ~ ~ ~ 0
effect clear @s minecraft:slowness
effect clear @s minecraft:jump_boost
particle minecraft:flash ~ ~1.5 ~ 0 0 0 0 1 force
particle minecraft:explosion_emitter ~ ~1 ~ 0 0 0 0 1 force
particle minecraft:end_rod ~ ~1.5 ~ 1 1 1 0.8 80 force
particle minecraft:sonic_boom ^ ^1.5 ^2 0 0 0 0 1 force
playsound minecraft:entity.generic.explode master @a ~ ~ ~ 8 0.5
playsound minecraft:entity.lightning_bolt.thunder master @a ~ ~ ~ 8 0.7
