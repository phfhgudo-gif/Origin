playsound thanpisitkub:garp_galaxydivide master @a ~ ~ ~ 6 1
effect give @s minecraft:resistance 26 4 true
effect give @s minecraft:slowness 25 6 true
effect give @s minecraft:jump_boost 25 128 true
scoreboard players set @s thp_gd 1
tag @s add thp_caster
thanpisitkub anim galaxy_divide
