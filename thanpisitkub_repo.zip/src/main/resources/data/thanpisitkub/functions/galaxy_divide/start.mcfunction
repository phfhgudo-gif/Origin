tag @s add thp_caster
scoreboard players set @s thp_gd 1
playsound thanpisitkub:garp_galaxydivide master @a ~ ~ ~ 6 1
effect give @s minecraft:resistance 14 4 true
effect give @s minecraft:slowness 6 6 true
effect give @s minecraft:jump_boost 6 128 true
