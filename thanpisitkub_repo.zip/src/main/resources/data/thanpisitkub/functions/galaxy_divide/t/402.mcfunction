execute rotated ~ 0 run particle thanpisitkub:garp_ult4_5_2 ^0.0 ^1.0 ^2.56 0 0 0 0 1 force
playsound minecraft:entity.generic.explode master @a ~ ~ ~ 6 0.6
execute rotated ~ 0 positioned ^ ^ ^6 run damage @e[tag=!thp_caster,distance=..7] 15 minecraft:player_attack by @s
execute rotated ~ 0 positioned ^ ^ ^14 run damage @e[tag=!thp_caster,distance=..7] 15 minecraft:player_attack by @s
execute rotated ~ 0 positioned ^ ^ ^22 run damage @e[tag=!thp_caster,distance=..7] 15 minecraft:player_attack by @s
execute rotated ~ 0 positioned ^ ^ ^30 run damage @e[tag=!thp_caster,distance=..7] 15 minecraft:player_attack by @s
execute rotated ~ 0 positioned ^ ^ ^38 run damage @e[tag=!thp_caster,distance=..7] 15 minecraft:player_attack by @s
execute rotated ~ 0 positioned ^ ^ ^46 run damage @e[tag=!thp_caster,distance=..7] 15 minecraft:player_attack by @s
execute rotated ~ 0 positioned ^ ^1 ^3 run particle minecraft:flash ~ ~ ~ 0 0 0 0 1 force
particle minecraft:sonic_boom ^ ^1.5 ^3 0 0 0 0 1 force
playsound minecraft:entity.lightning_bolt.thunder master @a ~ ~ ~ 8 0.7
