execute rotated ~ 0 run particle thanpisitkub:garp_ult1_3_3 ^0 ^1.0 ^0 0 0 0 0 1 force
execute rotated ~ 0 run particle thanpisitkub:garp_ult4_2_3 ^0 ^2.0 ^0.6 0 0 0 0 1 force
execute rotated ~ 0 run particle thanpisitkub:garp_ult4_2_3 ^0.8 ^1.0 ^-115.4 0 0 0 0 1 force
execute rotated ~ 0 run particle thanpisitkub:garp_ult4_2_3 ^61.7 ^1.0 ^-51.9 0 0 0 0 1 force
