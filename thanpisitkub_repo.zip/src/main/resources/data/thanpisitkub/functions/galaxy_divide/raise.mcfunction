particle minecraft:end_rod ~ ~3 ~ 1.2 2 1.2 0.15 10 force
particle minecraft:dust_color_transition 1 0.9 0 3 1 0.1 0 ~ ~3 ~ 1.5 2 1.5 0 20 force
particle minecraft:flame ~ ~2.5 ~ 0.8 1.5 0.8 0.15 6 force
particle minecraft:electric_spark ~ ~2 ~ 2 2 2 0.5 4 force
execute if score @s thp_gd matches 60 run particle minecraft:flash ~ ~2 ~ 0 0 0 0 1 force
