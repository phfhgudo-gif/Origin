scoreboard players reset @s thp_gi
scoreboard players reset @s thp_gd
scoreboard players set @s thp_death 0
tag @s remove thp_caster
kill @e[type=minecraft:marker,tag=thp_gd_mark,distance=..6]
