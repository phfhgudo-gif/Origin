thanpisitkub anim stop
scoreboard players reset @s thp_gi
scoreboard players reset @s thp_gd
scoreboard players set @s thp_death 0
tag @s remove thp_caster
effect clear @s minecraft:slowness
effect clear @s minecraft:jump_boost
