execute as @a[scores={thp_death=1..}] run function thanpisitkub:reset_all
execute as @a[scores={thp_gi=1..}] at @s run function thanpisitkub:galaxy_impact/tick
execute as @a[scores={thp_gd=1..}] at @s run function thanpisitkub:galaxy_divide/tick
