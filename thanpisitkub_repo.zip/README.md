# thanpisitkub (Origins add-on, Minecraft 1.20.1 Forge)

Origin `thanpisitkub`: Galaxy Impact (primary active key) + Galaxy Divide (secondary active key).

## Get the jar
1. Push this repo to GitHub.
2. Open the **Actions** tab -> **Build jar** -> latest run -> download the **thanpisitkub-jar** artifact.
3. Put the jar in `.minecraft/mods/` together with Forge 1.20.1, Origins, Apoli and Calio.

Local build (Java 17 + Gradle 8.1.1): `gradle build` -> `build/libs/thanpisitkub-1.0.0.jar`
