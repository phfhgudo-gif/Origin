# thanpisitkub (Origins add-on, Minecraft 1.20.1 Forge)

Origin `thanpisitkub`: **Galaxy Impact** (primary active key) and **Galaxy Divide** (secondary active key).

Needs in `mods/`: Forge 1.20.1, Origins (+ Apoli, Calio), and **Player Animator** (for the body animations).

Build: push to GitHub -> Actions -> "Build jar" -> download artifact `thanpisitkub-jar`.
